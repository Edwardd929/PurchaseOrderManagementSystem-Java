/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sigma.sdn.bhd;

import java.util.ArrayList;

/**
 *
 * @author vinni
 */
public class SalesManager extends User {
    
    
    public SalesManager(String SMID){
        super(SMID);
    }
    
    protected String getSMID() {
        return super.GetUserId();
    }

    protected void setSMID(String SMID) {
        super.SetUserId(SMID);
    }
    
    @Override
    protected ArrayList<String> GetAllUserId() {
        
        ArrayList<User> AllCustomerData = super.ReadUserData();
        
        ArrayList<String> SMUserIdList = new ArrayList<>();

        for (int i=0;i<AllCustomerData.size();i++) {
            if(AllCustomerData.get(i).GetRole().equals("Sales Manager")){
                String UserId = AllCustomerData.get(i).GetUserId();
                SMUserIdList.add(UserId);
            }
        }
        return SMUserIdList;
    }
    
    @Override
    public String toString() {
        // You can customize the format of the output here
        return "SM Id: " + getSMID() + "\nUsername: " + super.GetUsername() + "\nPassword: " + super.GetPassword() + "\nRole: " + super.GetRole() + "\n\n";
    }
    
    
}
