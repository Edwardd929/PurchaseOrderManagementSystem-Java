/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sigma.sdn.bhd;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Scanner;


/**
 *
 * @author vinni
 */
public class PurchaseOrder extends PurchaseRequisition implements PurchaseOrderManagement{
    String POID;
    String Status;
    private User PM;
    private String PODate;
    private String PSID;
    
    public PurchaseOrder(Item PRItem){
        super(PRItem);
    }
    
    //read PO
    public PurchaseOrder(String POID, User PM,String PSID, String PR, String ISID, String Status, String Date,Item PRItem){
        super(PRItem);
        this.POID = POID;
        this.PM = PM;
        this.PSID = PSID;
        super.SetPR(PR);
        super.SetPR_ItemSupplierID(ISID);
        super.SetItemID(super.GetData("Item ID"));
        super.setSupplier(new Supplier(super.GetData("Supplier ID")));
        super.setOrderQuantity(super.GetData("Order Quantity"));
        super.setRequiredDate(super.GetData("Required Date"));
        super.setTotalPrice(super.GetData("Total Price (RM)"));
        super.setReason(super.GetData("Reason"));
        super.setDate(super.GetData("Date"));
        this.Status = Status;
        this.PODate = Date;
    }
    
    
    //add item
    public PurchaseOrder(String POID, User PM, String PR, String ISID,Item PRItem){
        super(PRItem);
        this.POID = POID;
        this.PM = PM;
        super.SetPR(PR);
        super.SetPR_ItemSupplierID(ISID);
        char role = super.GetData("SM ID").charAt(0);
        if(role == 'A'){
            super.SetSM(new Admin(super.GetData("SM ID")));
        }else{
            super.SetSM(new SalesManager(super.GetData("SM ID")));
        }
        super.SetItemID(super.GetData("Item ID"));
        super.setSupplier(new Supplier(super.GetData("Supplier ID")));
        super.setOrderQuantity(super.GetData("Order Quantity"));
        super.setRequiredDate(super.GetData("Required Date"));
        super.setTotalPrice(super.GetData("Total Price (RM)"));
        super.setReason(super.GetData("Reason"));
        super.setDate(super.GetData("Date"));
    }
    
    
    //delete PO
    public PurchaseOrder(String POID, User PM,String PSID,Item PRItem){
        super(PRItem);
        this.POID = POID;
        this.PM = PM;
        this.PSID = PSID;
        super.SetPR(this.GetData("PR ID"));
        super.SetPR_ItemSupplierID(this.GetData("PR Line ID"));
        char role = super.GetData("SM ID").charAt(0);
        if(role == 'A'){
            super.SetSM(new Admin(super.GetData("SM ID")));
        }else{
            super.SetSM(new SalesManager(super.GetData("SM ID")));
        }
        super.SetItemID(super.GetData("Item ID"));
        super.setSupplier(new Supplier(super.GetData("Supplier ID")));
        super.setOrderQuantity(super.GetData("Order Quantity"));
        super.setRequiredDate(super.GetData("Required Date"));
        super.setTotalPrice(super.GetData("Total Price (RM)"));
        super.setReason(super.GetData("Reason"));
        super.setDate(super.GetData("Date"));
        
    }
    
    
    @Override
    protected void SetPR(String PRID){
        super.SetPR(PRID);
        String SM = super.GetAllData("SM ID");
        char role = SM.charAt(0);
        
        if(role == 'A'){
            super.SetSM(new Admin(super.GetAllData("SM ID")));
        }else{
            super.SetSM(new SalesManager(super.GetAllData("SM ID")));
        }
        super.SetItemID(super.GetData("Item ID"));
        super.setSupplier(new Supplier(super.GetData("Supplier ID")));
        super.setOrderQuantity(super.GetData("Order Quantity"));
        super.setRequiredDate(super.GetData("Required Date"));
        super.setTotalPrice(super.GetData("Total Price (RM)"));
        super.setReason(super.GetData("Reason"));
        super.setDate(super.GetData("Date"));
    }
    
    protected void SetPOID(){
        this.POID = GeneratePOId();
    }
    
    protected void SetPOID(String POID){
        this.POID = POID;
    }
    
    protected void SetPM(User PM){
        this.PM = PM;
    }
    
    
    protected void SetPSID(String PSID){
        this.PSID = PSID;
    }
    
    protected void SetPSID(){
        this.PSID = this.GeneratePSID(ReadPOInfo());
    }
    
    
    protected void SetStatus(String Status){
        this.Status = Status;
    }
    
    protected void SetPODate(String PODate){
        this.PODate = PODate;
    }
    
    
    protected String GetPOID(){
        return this.POID;
    }
    
    protected String getPRID(){
        return super.getPRID();
    }
        
    protected User GetPM(){
        return this.PM;
    }
    
    protected String GetPSID(){
        return this.PSID;
    }
    
    protected User getSM(){
        return super.getSM();
    }
    
    protected String GetStatus(){
        return this.Status;
    }
    
    protected String getPRDate(){
        return super.getDate();
    }
    
    protected String getPODate(){
        return this.PODate;
    }
   
    
    protected String getItemID() {
        return super.getItemID();
    }

    protected Supplier getSupplier() {
        return super.getSupplier();
    }
    protected void setSupplier(Supplier PRSupplier) {
        super.setSupplier(PRSupplier);
    }
        
    protected String getExpectedDeliveryDate() {
        return super.getExpectedDeliveryDate();
    }
    
    protected String getRequiredDate() {
        return super.getRequiredDate();
    }
    
    protected ArrayList<PurchaseRequisition> ReadPRInfo(){
        return super.ReadPRInfo();
    }
    
    public String[] GetAllPRIDs(){
        return super.GetAllPRIDs();
    }
    
    protected String getTotalPrice() {
        return super.getTotalPrice();
    }
    
    protected String getReason() {
        return super.getReason();
    }
    
    protected String getOrderQuantity() {
        return super.getOrderQuantity();
    }
    
    
    protected String getStockQuantity(){
        Stock ViewStock = new Stock(getItemID());
        return ViewStock.GetData("Stock Quantity");
    }
    
    protected String getReorderLevel(){
        Stock ViewStock = new Stock(getItemID());
        return ViewStock.GetData("Reorder Level");
    }
    

    protected ArrayList<PurchaseOrder> ReadPOInfo(){
        File POInfoFile = new File("data/PurchaseOrder.txt");
        
        ArrayList<PurchaseOrder> AllPOInfo = new ArrayList<>();
        
        try {
            Scanner sc = new Scanner(POInfoFile);
            
            PurchaseOrder ReadPO;
            while (sc.hasNextLine()){
                String ln = sc.nextLine();
                
                if (!ln.trim().isEmpty()){
                    String POId= ln.split(":")[1].trim();
                    String PSID = sc.nextLine().split(":")[1].trim();
                    String PRId = sc.nextLine().split(":")[1].trim();
                    String ISID = sc.nextLine().split(":")[1].trim();
                    String ID = sc.nextLine().split(":")[1].trim();
                    String Date = sc.nextLine().split(":")[1].trim();
                    String Status = sc.nextLine().split(":")[1].trim();
                    
                    
                    
                    char role = ID.charAt(0);
                    if(role=='P'){
                        ReadPO = new PurchaseOrder(POId,new PurchaseManager(ID),PSID,PRId,ISID,Status,Date, new Item());
                    }else if(role=='A'){
                        ReadPO = new PurchaseOrder(POId,new Admin(ID),PSID,PRId,ISID,Status,Date, new Item());      
                    }else{
                        ReadPO = null;
                    }
                  
                    AllPOInfo.add(ReadPO);
                } else {
                    ReadPO = null;
                    
                }
            }
            sc.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return AllPOInfo;
    }

        
    protected void WritePO(Supplier PRSupplier){
            File file = new File("data/PurchaseOrder.txt");
            this.SetPODate(PODate());
            try {
                FileWriter w = new FileWriter(file, true);
                
                w.write("PO ID: " + this.POID + "\n");
                w.write("PO Line ID: " + this.PSID + "\n");
                w.write("PR ID: " + super.PRID + "\n");
                w.write("PR Line ID: " + super.GetPR_ItemSupplierID() + "\n");
                w.write("PM ID: " + this.PM.GetUserId()+ "\n");
                w.write("Date: " + this.getPODate() + "\n");
                w.write("Status: " + this.Status + "\n\n");
                w.close();
            }
            catch(IOException e){
                e.printStackTrace();
            }
            
            
    }
    
    private String GeneratePOId() {
        
        int ID = 0;
        ID = Integer.parseInt(this.getSupplier().GetSupplierId().substring(2));
        String NewPRId = "PO" + ID;
        return NewPRId;
        
    }
    
    protected String PODate(){
        Date date = new Date();
        LocalDateTime now = LocalDateTime.ofInstant(date.toInstant(), java.time.ZoneId.systemDefault());
        String FormattedDate = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        return FormattedDate;
    }
    
    
    public ArrayList<PurchaseOrder> GetPOFromSamePM() {
        ArrayList<PurchaseOrder> AllPOData = ReadPOInfo();
        ArrayList<PurchaseOrder> POFromSamePM = new ArrayList<>();

        for (PurchaseOrder APO : AllPOData) {
            
            if (APO.GetPM().GetUserId().equals(this.GetPM().GetUserId())) {
                POFromSamePM.add(APO);
            }
        }

        return POFromSamePM;
    }
        
    
    private String GetPOData(ArrayList<PurchaseOrder> AllPOData, String POID, String var){
        int size = AllPOData.size();
        for(int i=0;i<size;i++){
            if(AllPOData.get(i).GetPOID().equals(this.POID)&&AllPOData.get(i).GetPSID().equals(this.PSID)){
                if(var.equals("PM ID")){
                    return (AllPOData.get(i).GetPM().GetUserId());

                }else if(var.equals("PR ID")){
                    return (String.valueOf(AllPOData.get(i).getPRID()));
                }else if(var.equals("PR Line ID")){
                    return (String.valueOf(AllPOData.get(i).GetPR_ItemSupplierID()));
                }else if(var.equals("Status")){
                    return (String.valueOf(AllPOData.get(i).GetStatus()));
                }else if(var.equals("Date")){
                    return (AllPOData.get(i).getDate());
                }
            }
        }
        return null;
    }
    
    protected String GetData(String var){
        return GetPOData(ReadPOInfo(),this.POID,var);
    }
    
    private void DeleteArray(ArrayList<PurchaseOrder> AllPOData) {
       for (int i = 0; i < AllPOData.size(); i++) {
            if (AllPOData.get(i).GetPOID().equals(this.POID) && AllPOData.get(i).GetPSID().equals(this.PSID)) {
                AllPOData.get(i).SetStatus("NA");
                super.EditStatus("Cancelled");
            }
        }
        SaveData(AllPOData);
        
    }
    
    protected void Delete() {
       DeleteArray(ReadPOInfo());
    }
    
        


        
    private void SaveData(ArrayList<PurchaseOrder> AllPOData){
        File file = new File("data/PurchaseOrder.txt");
        // relative file paths

        try {
            // Create a FileWriter object to write to the file
            FileWriter writer = new FileWriter(file,false);
            
            
        for (int i = 0; i < AllPOData.size(); i++) {
           // Write the user input to the file
            writer.write("PO ID: "+ AllPOData.get(i).GetPOID()+ "\n");
            writer.write("PO Line ID: "+ AllPOData.get(i).GetPSID()+ "\n");
            writer.write("PR ID: " + AllPOData.get(i).getPRID()  + "\n");
            writer.write("PR Line ID: " + AllPOData.get(i).GetPR_ItemSupplierID()+ "\n");
            writer.write("PM ID: " + AllPOData.get(i).GetPM().GetUserId()+ "\n");
            writer.write("Date: " + AllPOData.get(i).getDate() + "\n");
            writer.write("Status: " + AllPOData.get(i).GetStatus()  + "\n\n");
            
        }    
            
            // Close the FileWriter
            writer.close();

            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private ArrayList<String[]> CreatePOArray(ArrayList<PurchaseOrder> AllPOData){
        ArrayList<String[]> POList = new ArrayList<>();
        
        String ID;
        
            
        for (int i = 0; i < AllPOData.size(); i++) {
            
            ID = AllPOData.get(i).GetPM().GetUserId();
            
            String[] PO = new String[]{
                AllPOData.get(i).GetPOID(),
                AllPOData.get(i).GetPSID(),
                ID,
                AllPOData.get(i).getPRID(),
                AllPOData.get(i).GetPR_ItemSupplierID(),
                AllPOData.get(i).getSupplier().GetSupplierId(),
                AllPOData.get(i).getItemID(),
                AllPOData.get(i).getOrderQuantity(),
                AllPOData.get(i).getTotalPrice(),
                AllPOData.get(i).getRequiredDate(),
                AllPOData.get(i).getDate(),
                AllPOData.get(i).GetStatus()
                    
                    
            };
            
            
            POList.add(PO);
        }

        return POList;
    }
    
    
    public ArrayList<String[]> GetPODataArray(){
        return CreatePOArray(ReadPOInfo());
    }
    
    private ArrayList<String[]> CreateFilterPOIDPRArray(ArrayList<PurchaseOrder> AllPOData, String POID){
        ArrayList<String[]> POList = new ArrayList<>();
        
        for (int i = 0; i < AllPOData.size(); i++){
            
            if(!(AllPOData.get(i).GetPOID().equals(POID))){
                continue;
            }
            
            String ID;

            ID = AllPOData.get(i).GetPM().GetUserId();

            
            String[] PO = new String[]{
                AllPOData.get(i).GetPOID(),
                AllPOData.get(i).GetPSID(),
                ID,
                AllPOData.get(i).getPRID(),
                AllPOData.get(i).GetPR_ItemSupplierID(),
                AllPOData.get(i).getSupplier().GetSupplierId(),
                AllPOData.get(i).getItemID(),
                AllPOData.get(i).getOrderQuantity(),
                AllPOData.get(i).getTotalPrice(),
                AllPOData.get(i).getRequiredDate(),
                AllPOData.get(i).getDate(),
                AllPOData.get(i).GetStatus()
                    
                    
            };
            
            
            POList.add(PO);
        }
        
        return POList;
    }
    
    public ArrayList<String[]> GetFilterPOIDPRArray(String POID){
        return CreateFilterPOIDPRArray(ReadPOInfo(),POID);
    }
    
     private ArrayList<String[]> CreateFilterStatusPOArray(ArrayList<PurchaseOrder> AllPOData, String Status){
        ArrayList<String[]> PRList = new ArrayList<>();
        
        for (int i = 0; i < AllPOData.size(); i++){
            
            if(!(AllPOData.get(i).GetStatus().equals(Status))){
                continue;
            }
            
            String ID;

            ID = AllPOData.get(i).GetPM().GetUserId();

            
            
            String[] PO = new String[]{
                AllPOData.get(i).GetPOID(),
                AllPOData.get(i).GetPSID(),
                ID,
                AllPOData.get(i).getPRID(),
                AllPOData.get(i).GetPR_ItemSupplierID(),
                AllPOData.get(i).getSupplier().GetSupplierId(),
                AllPOData.get(i).getItemID(),
                AllPOData.get(i).getOrderQuantity(),
                AllPOData.get(i).getTotalPrice(),
                AllPOData.get(i).getRequiredDate(),
                AllPOData.get(i).getDate(),
                AllPOData.get(i).GetStatus()
                    
                    
            };
            
            
            PRList.add(PO);
        }
        
        return PRList;
    }
    
    public ArrayList<String[]> GetFilterStatusPOArray(String Status){
        return CreateFilterStatusPOArray(ReadPOInfo(),Status);
    }
    
    //generate a new PSID
    private String GeneratePSID(ArrayList<PurchaseOrder> AllPOInfo) {
        int maxID = 0;
        int currentID =0;
        for(PurchaseOrder APO: AllPOInfo){
            if(APO.GetPOID().equals(this.GetPOID())){
                currentID = Integer.parseInt(APO.GetPSID().substring(2));
                if(currentID>maxID){
                    maxID= currentID;
                }  
            }
        }
        if(maxID!=0){
            maxID++;
            String NewPSId = "PS" + maxID;
            return NewPSId;
        }else{
            maxID = 1;
            String NewPSId = "PS" + maxID;
            return NewPSId;
        }

    }
    
    private String[] GetPSIDFromSamePO(ArrayList<PurchaseOrder> AllPOData) {
        ArrayList<String> PSIDArrayList = new ArrayList<>();
        int size = AllPOData.size();

        for (int i = 0; i < size; i++) {
            if(AllPOData.get(i).GetPOID().equals(this.POID)&& AllPOData.get(i).GetStatus().equals("A")){
                String PSID = AllPOData.get(i).GetPSID();
                PSIDArrayList.add(PSID);
            }
            
        }

        // Convert the ArrayList to an array of Strings
        String[] PSIDList = new String[PSIDArrayList.size()];
        PSIDList = PSIDArrayList.toArray(PSIDList);

        return PSIDList;
    }
        
    public String[] GetPSIDFromSamePOs(){
        return GetPSIDFromSamePO(ReadPOInfo());
    }
    
    private boolean StatusCheck(ArrayList<PurchaseOrder> AllPOInfo){
        for(PurchaseOrder APO: AllPOInfo){
            if(APO.GetPM().equals(this.POID) && APO.GetStatus().equals("Pending")){
                return true;
            }
        }
        
        for (PurchaseOrder APO : AllPOInfo) {

            if (APO.GetPM().GetUserId().equals(this.GetPM().GetUserId())&& 
                    APO.GetStatus().equals("A")) {
                return true;
            }
            
        }
        
        return false;
    }
    
    protected boolean StatusCheck(){
        return StatusCheck(ReadPOInfo());
    }
    
    private String[] GetFilterPOID(ArrayList<PurchaseOrder> AllPOInfo) {
        HashSet<String> POIDSet = new HashSet<>();

        for (PurchaseOrder APO : AllPOInfo) {
            String POID = APO.GetPOID();
            POIDSet.add(POID);
        }
        String[] UniquePOID = POIDSet.toArray(new String[0]);

        return UniquePOID;
    }
    
    public String[] GetFilterPOIDs(){
        return GetFilterPOID(ReadPOInfo());
    }
    
   

}
