/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sigma.sdn.bhd;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;


public class Stock{
    private String SalesQuantity;
    private int SalesQuantityNum;
    private String StockStatus;
    private int StockQuantity;
    private int ReorderLevel;
    private String ItemId;
    
    
    
    
    public Stock(String ItemId){
        this.ItemId = ItemId;
    }
    
    //add new item and edit reorder level
    public Stock(String ItemId, int ReorderLevel){
        this.ItemId = ItemId;
        this.ReorderLevel = ReorderLevel;
    }
        
    public Stock(String ItemId, String SalesQuantity){
        this.ItemId = ItemId;
        this.SalesQuantity = SalesQuantity;
    }
    
    public Stock(String ItemId, int StockQuantity, int ReorderLevel, String StockStatus){
        this.ItemId = ItemId;
        this.StockQuantity=StockQuantity;
        this.ReorderLevel = ReorderLevel;
        this.StockStatus = StockStatus;
    }
    
    public Stock(){
    }
    
    protected void SetItemID(String ItemID){
        this.ItemId = ItemId;
    }
    
    protected void SetReorderLevel(int ReorderLevel){
        this.ReorderLevel = ReorderLevel;
    }
    
    protected void SetStockQuantity(int StockQuantity){
        this.StockQuantity = StockQuantity;
    }
    
    protected void SetStockStatus(String StockStatus){
        this.StockStatus = StockStatus;
    }
    
    protected String GetStockStatus(){
        return this.StockStatus ;
    }
        
    protected String GetItemId(){
        return this.ItemId;
    }
    
    protected int GetStockQuantity(){
        return this.StockQuantity;
    }
    
    protected int GetReorderLevel(){
        return this.ReorderLevel;
    }

    protected String GetStockData(ArrayList<Stock> AllStockData, String ItemID, String var){
        int size = AllStockData.size();
        for(int i=0;i<size;i++){
            if(AllStockData.get(i).GetItemId().equals(this.GetItemId())){
                if(var.equals("Stock Quantity")){
                    return (String.valueOf(AllStockData.get(i).GetStockQuantity()));
                }else if(var.equals("Reorder Level")){
                    return (String.valueOf(AllStockData.get(i).GetReorderLevel()));
                }else if(var.equals("Status")){
                    return (String.valueOf(AllStockData.get(i).GetStockStatus()));
                }
            }
        }
        return null;
    }
    
    protected String GetData(String var){
        return GetStockData(ReadStockData(),GetItemId(),var);
    }

    
    
    protected ArrayList<Item> ReadItemData() {

        // Create a new file object to read from
        File ItemDataFile = new File("data/ItemInfo.txt");

        // Create an ArrayList to store the customer data
        ArrayList<Item> AllItemData = new ArrayList<>();


        try {
            // Create a new Scanner object to read from the file
            Scanner scanner = new Scanner(ItemDataFile);
            
            Item ReadItem;
            // Read each line of the file
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();

                if (!line.trim().isEmpty()) {
                    String itemid = line.split(":")[1].trim();
                    String itemname = scanner.nextLine().split(":")[1].trim();
                    String itemprice = scanner.nextLine().split(":")[1].trim();
                    String supplierid = scanner.nextLine().split(":")[1].trim();
                    String status = scanner.nextLine().split(":")[1].trim();
                    
                    ReadItem = new Item(itemid,itemname,itemprice,new Supplier(supplierid),status);
                    AllItemData.add(ReadItem);
                }else{
                    ReadItem = null;
                    continue;
                }
               
            }
          // Close the scanner
            scanner.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        return AllItemData;
    }
    
    protected String GetItemData(ArrayList<Item> AllItemData, String ItemID, String var){
        int size = AllItemData.size();
        for(int i=0;i<size;i++){
            if(AllItemData.get(i).GetItemId().equals(ItemID)){
                if(var.equals("Item Name")){
                    return (AllItemData.get(i).GetItemName());
                }else if(var.equals("Item Price(RM)")){
                    return (AllItemData.get(i).GetItemPrice());
                }else if(var.equals("Supplier Id")){
                    return (AllItemData.get(i).GetSupplierCode());
                }else if(var.equals("Status")){
                    return (AllItemData.get(i).GetItemStatus());
                }
            }
        }
        return null;
    }
    
    protected ArrayList<Stock> ReadStockData() {
        // Create a new file object to read from
        File StockDataFile = new File("data/StockQuantity.txt");

        // Create an ArrayList to store the customer data
        ArrayList<Stock> AllStockData = new ArrayList<>();


        try {
            // Create a new Scanner object to read from the file
            Scanner scanner = new Scanner(StockDataFile);
            
            Stock ReadStock;
            // Read each line of the file
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();

                if (!line.trim().isEmpty()) {
                    String itemid = line.split(":")[1].trim();
                    int stockquantity = Integer.parseInt(scanner.nextLine().split(":")[1].trim());
                    int reorderlevel = Integer.parseInt(scanner.nextLine().split(":")[1].trim());
                    String Status = scanner.nextLine().split(":")[1].trim();
                    ReadStock = new Stock(itemid, stockquantity,reorderlevel,Status);
                    AllStockData.add(ReadStock);
                }else{
                    ReadStock = null;
                    continue;
                }
                
            }
            // Close the scanner
            scanner.close();
            

        } catch (IOException e) {
            e.printStackTrace();
        }
        

        return AllStockData;
    }
    
    private ArrayList<String[]> CreateStockArray(ArrayList<Item> AllItemData,ArrayList<Stock> AllStockData){
        ArrayList<String[]> ItemList = new ArrayList<>();

        for (int i = 0; i< AllStockData.size(); i++) {
            String[] Item = new String[]{
                AllStockData.get(i).GetItemId(),
                GetItemData(AllItemData,AllStockData.get(i).GetItemId(),"Item Name"),
                String.valueOf(AllStockData.get(i).GetStockQuantity()),
                String.valueOf(AllStockData.get(i).GetReorderLevel()),
                String.valueOf(AllStockData.get(i).GetStockStatus())
            };

            ItemList.add(Item);
        }

        return ItemList;
    }
    
    protected ArrayList<String[]> GetStockDataArray(){
        return CreateStockArray(ReadItemData(), ReadStockData());
    }
    
    private ArrayList<String[]> CreateLowerStockArray(ArrayList<Item> AllItemData,ArrayList<Stock> AllStockData){
        ArrayList<String[]> ItemList = new ArrayList<>();

        for (int i = 0; i< AllStockData.size(); i++) {
            if(AllStockData.get(i).GetStockQuantity()>=AllStockData.get(i).GetReorderLevel()){
                continue;
            }
            String[] Item = new String[]{
                AllStockData.get(i).GetItemId(),
                GetItemData(AllItemData,AllStockData.get(i).GetItemId(),"Item Name"),
                String.valueOf(AllStockData.get(i).GetStockQuantity()),
                String.valueOf(AllStockData.get(i).GetReorderLevel()),
                String.valueOf(AllStockData.get(i).GetStockStatus())
            };

            ItemList.add(Item);
        }

        return ItemList;
    }
    
    protected ArrayList<String[]> GetLowerStockDataArray(){
        return CreateLowerStockArray(ReadItemData(), ReadStockData());
    }
    
    private boolean SaveData(ArrayList<Stock> AllStockData,int SalesQuantity){
        int StockQuantity;      
        int RemainQuantity =(Integer.parseInt(this.GetData("Stock Quantity"))-SalesQuantity);
        if(RemainQuantity<0){
            return false;
        }else{
            File file = new File("data/StockQuantity.txt");
            // relative file paths

            try {
                // Create a FileWriter object to write to the file
                FileWriter writer = new FileWriter(file,false);


                for (int i = 0; i< AllStockData.size(); i++) {

                    if(AllStockData.get(i).GetItemId().equals(this.GetItemId())){
                        StockQuantity = AllStockData.get(i).GetStockQuantity() - SalesQuantity;
                    }else{
                       StockQuantity = AllStockData.get(i).GetStockQuantity();
                    }

                    writer.write("Item Id: "+ AllStockData.get(i).GetItemId() + "\n");
                    writer.write("Stock Quantity: " + StockQuantity + "\n");
                    writer.write("Reorder Level: " + AllStockData.get(i).GetReorderLevel() + "\n" );
                    writer.write("Status: " + AllStockData.get(i).GetStockStatus()+ "\n\n" );
                }
                // Close the FileWriter
                writer.close();


            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return true;
    }
    
    private void SaveData(ArrayList<Stock> AllStockData){
        File file = new File("data/StockQuantity.txt");
        // relative file paths

        try {
            // Create a FileWriter object to write to the file
            FileWriter writer = new FileWriter(file,false);
            
            for (int i = 0; i< AllStockData.size(); i++) {
               // Write the user input to the file
                writer.write("Item Id: "+ AllStockData.get(i).GetItemId() + "\n");
                writer.write("Stock Quantity: " + AllStockData.get(i).GetStockQuantity() + "\n");
                writer.write("Reorder Level: "+ AllStockData.get(i).GetReorderLevel()+ "\n" );
                writer.write("Status: "+ AllStockData.get(i).GetStockStatus()+ "\n\n" );
            }    
            
            // Close the FileWriter
            writer.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    protected void AddItemToStock(String ItemId){
        File file = new File("data/StockQuantity.txt");
        try {
            // Create a FileWriter object to write to the file
            FileWriter writer = new FileWriter(file,true);
            
            // Write the user input to the file
            writer.write("Item Id: "+ ItemId + "\n");
            writer.write("Stock Quantity: 0 \n" );
            writer.write("Reorder Level: "+this.GetReorderLevel()+"\n" );
            writer.write("Status: A"+"\n\n" );

            // Close the FileWriter
            writer.close();

            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    protected void DeleteItemFromStock(){
        ArrayList<Stock> AllStockData = ReadStockData();
        
        for (int i = 0; i< AllStockData.size(); i++) {
            if (AllStockData.get(i).GetItemId().equals(this.ItemId)) {
                
                AllStockData.get(i).SetStockStatus(this.GetStockStatus());
                
                break;
            }
        }
        
        SaveData(AllStockData);
    }
    
    protected void EditItemFromStock() {
        ArrayList<Stock> AllStockData = ReadStockData();
        for (int i = 0; i < AllStockData.size(); i++) {
            if (AllStockData.get(i).GetItemId().equals(this.GetItemId())) {
                AllStockData.get(i).SetReorderLevel(this.GetReorderLevel());
            }
        }

        SaveData(AllStockData);
    }
    
    protected String CheckStockInput(){
        ArrayList<Stock> ALlStockData = ReadStockData();
        if(this.GetItemId().isEmpty() || this.SalesQuantity.isEmpty()){
            return "Incomplete";
        }else{
            try {
                SalesQuantityNum = Integer.parseInt(this.SalesQuantity);
            } catch (NumberFormatException e) {
                return "Not Number";
            }
            if(SaveData(ALlStockData,SalesQuantityNum)){
                return "Correct";
            }else{
                return "Exceed Stock Quantity";
            }
            
        }
    }
    
    private void EditStockQuantityArray( int stockquantity) {
        ArrayList<Stock> AllStockData = ReadStockData();
        for (int i = 0; i < AllStockData.size(); i++) {
            if (AllStockData.get(i).GetItemId().equals(this.ItemId)) {
                AllStockData.get(i).SetStockQuantity(stockquantity);
            }
        }

        // Write the updated item data back to the file
        SaveData(AllStockData);
    }
    
    protected void EditStockQuantity(int stockquantity){
        EditStockQuantityArray(stockquantity);
    }

}
