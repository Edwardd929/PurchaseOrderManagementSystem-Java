/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sigma.sdn.bhd;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Scanner;

/**
 *
 * @author vinni
 */
public class PurchaseRequisition implements PurchaseRequisitionManagement{
    
    public String PRID;
    private String OrderQuantity;
    private String RequiredDate;
    private String Reason;
    private String TotalPrice;
    private User user;
    private String PRDate;
    private String PR_ItemSupplierID;
    private String status;
    private Item PRItem;
    
    public PurchaseRequisition(String PRID, User user,String PR_ItemSupplierID,Item PRItem,Supplier PRSupplier, String OrderQuantity,String RequiredDate, String TotalPrice,String Reason,  String Status){
        this.PRID = PRID;
        this.user = user;
        this.PR_ItemSupplierID = PR_ItemSupplierID;
        this.PRItem = PRItem;
        PRItem.SetSupplier(PRSupplier);
        this.OrderQuantity = OrderQuantity;
        this.RequiredDate = RequiredDate;
        this.TotalPrice = TotalPrice;
        this.Reason = Reason;
        this.status = Status;
    }
    
    
    
    
    //read/edit PR
    public PurchaseRequisition(String PRID, User user,String PR_ItemSupplierID,Item PRItem,Supplier PRSupplier,String OrderQuantity, String RequiredDate, String TotalPrice,String Reason,  String PRDate, String status){
        this.PRID = PRID;
        this.user = user;
        this.PR_ItemSupplierID = PR_ItemSupplierID;
        this.PRItem = PRItem;
        PRItem.SetSupplier(PRSupplier);
        this.OrderQuantity = OrderQuantity;
        this.RequiredDate = RequiredDate;
        this.TotalPrice = TotalPrice;
        this.Reason= Reason;
        this.PRDate = PRDate;
        this.status = status;
    }
    
    
    //edit, delete, view all PR
    public PurchaseRequisition(String PRID,User user,String PR_ItemSupplierID,Item PRItem){ 
        this.PRID = PRID;
        this.user = user;
        this.PR_ItemSupplierID = PR_ItemSupplierID;
        this.PRItem = PRItem;
        PRItem.SetItemID(this.GetData("Item ID"));
        PRItem.SetSupplier(new Supplier(this.GetData("Supplier ID")));

    }
   
    
    
    public PurchaseRequisition(String PRID,Item PRItem){
        this.PRID = PRID;
        this.PRItem = PRItem;
        
    }
    
    public PurchaseRequisition(Item PRItem){
        this.PRItem = PRItem;
    }
    
    public PurchaseRequisition(User user,Item PRItem){
        this.user = user;
        this.PRItem = PRItem;
    }
    
    //add PR
    protected void SetPR() {
        this.PRID = GeneratePRID(ReadPRInfo());
        
    }

    protected void SetPR(String PRID) {
        this.PRID = PRID;
    }
    
    protected String getPRID() {
        return this.PRID;
    }
        
    protected void SetSM(User user) {
        this.user = user;
    }
    
    
    protected void SetPR_ItemSupplierID(){
        this.PR_ItemSupplierID = this.GenerateISID(ReadPRInfo());
       
    }
    
    protected void SetPR_ItemSupplierID(String PR_ItemSupplierID){
        this.PR_ItemSupplierID = PR_ItemSupplierID;
    }
    
    protected String GetPR_ItemSupplierID(){
        return this.PR_ItemSupplierID;
    }
    
    protected void SetStatus(String Status){
        this.status= Status;
    }
    
    protected String GetStatus(){
        return this.status;
    }
    
    
    protected String getOrderQuantity() {
        return OrderQuantity;
    }

    protected void setOrderQuantity(String OrderQuantity) {
        this.OrderQuantity = OrderQuantity;
    }

    protected String getRequiredDate() {
        return this.RequiredDate;
    }

    protected void setRequiredDate(String RequiredDate) {
        this.RequiredDate = RequiredDate;
    }
    
    protected String getExpectedDeliveryDate(){
        return PRItem.GetSupplier().GetData("Expected Delivery Time(days)");
    }
    
    protected String getItemID() {
        return PRItem.GetItemId();
    }

    protected void SetItemID(String ItemID) {
        PRItem.SetItemID(ItemID);
    }

    protected User getSM() {
        return user;
    }

    protected void setSupplier(Supplier PRSupplier) {
        PRItem.SetSupplier(PRSupplier);
    }
    
    protected Supplier getSupplier() {
        return PRItem.GetSupplier();
    }
    
    protected void setTotalPrice(String TotalPrice) {
        this.TotalPrice = TotalPrice;
    }
    
    protected void setReason(String Reason) {
        this.Reason = Reason;
    }
    
    protected void setDate(String PRDate){
        this.PRDate = PRDate;
    }
    
    protected String getDate(){
        return this.PRDate;
    }
    
    protected String getTotalPrice() {
        return this.TotalPrice;
    }
    
    protected String getReason() {
        return this.Reason;
    }
    
    protected String getItemInfo(String var){
        return PRItem.GetData(var);
    }
    
    protected PurchaseRequisition getPR() {
        return this;
    }
        
    // function to check for PRID
    protected boolean CheckPRID(){
        return true;
    }
    


    // creating an arraylist to read PR info
    protected ArrayList<PurchaseRequisition> ReadPRInfo(){
        File PRInfoFile = new File("data/PurchaseRequisition.txt");
        
        ArrayList<PurchaseRequisition> AllPRInfo = new ArrayList<>();
        
        try {
            Scanner sc = new Scanner(PRInfoFile);
            
            PurchaseRequisition ReadPR;
            while (sc.hasNextLine()){
                String ln = sc.nextLine();
                
                if (!ln.trim().isEmpty()){
                    String prid= ln.split(":")[1].trim();
                    String isid = sc.nextLine().split(":")[1].trim();
                    String itemid = sc.nextLine().split(":")[1].trim();
                    String supplierid = sc.nextLine().split(":")[1].trim();
                    String orderquantity = sc.nextLine().split(":")[1].trim();
                    String requireddate = sc.nextLine().split(":")[1].trim();
                    String ThisTotalPrice = sc.nextLine().split(":")[1].trim();
                    String reason = sc.nextLine().split(":")[1].trim();
                    String id = sc.nextLine().split(":")[1].trim();
                    String CreatePRDate = sc.nextLine().split(":")[1].trim();
                    String status = sc.nextLine().split(":")[1].trim();
                    
                    char role = id.charAt(0);
                    
                    if(role == 'A'){
                        ReadPR = new PurchaseRequisition(prid, new Admin(id),isid,new Item(itemid), new Supplier(supplierid), orderquantity,requireddate,ThisTotalPrice,reason, CreatePRDate,
                    status);
                    }else{
                        ReadPR = new PurchaseRequisition(prid, new SalesManager(id),isid,new Item(itemid), new Supplier(supplierid), orderquantity,requireddate,ThisTotalPrice,reason, CreatePRDate,
                    status);
                    }
                    

                    
                    AllPRInfo.add(ReadPR);
                } else {
                    ReadPR = null;
                    
                }
            }
            sc.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return AllPRInfo;
    }
   
    private String[] GetAllPRID(ArrayList<PurchaseRequisition> AllPRData) {
        ArrayList<String> PRIDArrayList = new ArrayList<>();
        int size = AllPRData.size();

        for (int i = 0; i < size; i++) {
            if(AllPRData.get(i).GetStatus().equals("Pending")){
                String PRID = AllPRData.get(i).getPRID();
                PRIDArrayList.add(PRID);
            }
            
        }

        // Convert the ArrayList to an array of Strings
        String[] PRIDList = new String[PRIDArrayList.size()];
        PRIDList = PRIDArrayList.toArray(PRIDList);

        return PRIDList;
    }
    
    
    public String[] GetAllPRIDs(){
        return GetAllPRID(ReadPRInfo());
    }
    
    private String[] GetISIDFromSamePR(ArrayList<PurchaseRequisition> AllPRData) {
        ArrayList<String> ISIDArrayList = new ArrayList<>();
        int size = AllPRData.size();

        for (int i = 0; i < size; i++) {
            if(AllPRData.get(i).getPRID().equals(this.PRID)&& AllPRData.get(i).GetStatus().equals("Pending")){
                String ISID = AllPRData.get(i).GetPR_ItemSupplierID();
                ISIDArrayList.add(ISID);
            }
            
        }

        // Convert the ArrayList to an array of Strings
        String[] ISIDList = new String[ISIDArrayList.size()];
        ISIDList = ISIDArrayList.toArray(ISIDList);

        return ISIDList;
    }
        
    public String[] GetISIDFromSamePRs(){
        return GetISIDFromSamePR(ReadPRInfo());
    }
    
    // generating a new PRID
    private String GeneratePRID(ArrayList<PurchaseRequisition> AllPRInfo) {
        int ID = 0;
        if(user instanceof Admin){
            ID = Integer.parseInt(this.getSM().GetUserId().substring(1));
            String NewPRId = "PR" + ID +"A";
            return NewPRId;
        }else{
            ID = Integer.parseInt(getSM().GetUserId().substring(1));
            String NewPRId = "PR" + ID;
            return NewPRId;
        }
    }
    
    // generating a new ItemSupplier ID
    private String GenerateISID(ArrayList<PurchaseRequisition> AllPRInfo) {
        int maxID = 0;
        int currentID =0;
        for(PurchaseRequisition APR: AllPRInfo){
            if(APR.getPRID().equals(this.getPRID())){
                currentID = Integer.parseInt(APR.GetPR_ItemSupplierID().substring(2));
                if(currentID>maxID){
                    maxID= currentID;
                }  
            }
        }
        if(maxID!=0){
            maxID++;
            String NewISId = "IS" + maxID;
            return NewISId;
        }else{
            maxID = 1;
            String NewISId = "IS" + maxID;
            return NewISId;
        }

    }
        


    // adding PR into the textfile
    protected boolean CreatePR(){
        File file = new File("data/PurchaseRequisition.txt");
        this.setDate(PRDate());
        if(!DuplicatedCheck(ReadPRInfo())){
            try {
                FileWriter w = new FileWriter(file, true);

                w.write("PR ID: " + this.PRID + "\n");
                w.write("PR Line ID: " + this.GetPR_ItemSupplierID() + "\n");
                w.write("Item ID: " + this.getItemID() + "\n");
                w.write("Supplier ID: " + PRItem.GetSupplier().GetSupplierId() + "\n");
                w.write("Order Quantity: " + this.OrderQuantity + "\n");
                w.write("Required Date: " + this.getRequiredDate() + "\n");
                w.write("Total Price (RM): " + this.TotalPrice + "\n");
                w.write("Reason: " + this.Reason + "\n");
                w.write("SM ID: " + this.user.GetUserId()+ "\n");
                w.write("Date: " + this.getDate() + "\n");
                w.write("Status: " + this.GetStatus()+ "\n\n");

                w.close();
            }
            catch(IOException e){
                e.printStackTrace();
            }
            return true;
        }else{
            return false;
        }
    }
    
    private String GetPRData(ArrayList<PurchaseRequisition> AllPRData, String PRID,String ISID, String var){
        int size = AllPRData.size();
        for(int i=0;i<size;i++){
            if(AllPRData.get(i).getPRID().equals(PRID)&&AllPRData.get(i).GetPR_ItemSupplierID().equals(ISID)){
                if(var.equals("SM ID")){
                     return (AllPRData.get(i).getSM().GetUserId());
                    
                }else if(var.equals("Item ID")){
                    return (AllPRData.get(i).getItemID());
                }else if(var.equals("Supplier ID")){
                    return (String.valueOf(AllPRData.get(i).getSupplier().GetSupplierId()));
                }else if(var.equals("Order Quantity")){
                    return (AllPRData.get(i).getOrderQuantity());
                }else if(var.equals("Required Date")){
                    return (AllPRData.get(i).getRequiredDate());
                }else if(var.equals("Total Price (RM)")){
                    return (AllPRData.get(i).getTotalPrice());
                }else if(var.equals("Reason")){
                    return (AllPRData.get(i).getReason());
                }else if(var.equals("Date")){
                    return (AllPRData.get(i).getDate());
                }else if(var.equals("Status")){
                    return (AllPRData.get(i).GetStatus());
                }
            }
        }
        return null;
    }
    
    
    
    private String GetAllPRData(ArrayList<PurchaseRequisition> AllPRData, String PRID, String var){
        int size = AllPRData.size();
        for(int i=0;i<size;i++){
            if(AllPRData.get(i).getPRID().equals(PRID)){
                if(var.equals("SM ID")){
                    return (AllPRData.get(i).getSM().GetUserId());
                }else if(var.equals("Item ID")){
                    return (AllPRData.get(i).getItemID());
                }else if(var.equals("Supplier ID")){
                    return (String.valueOf(AllPRData.get(i).getSupplier().GetSupplierId()));
                }else if(var.equals("Order Quantity")){
                    return (AllPRData.get(i).getOrderQuantity());
                }else if(var.equals("Required Date")){
                    return (AllPRData.get(i).getRequiredDate());
                }else if(var.equals("Total Price (RM)")){
                    return (AllPRData.get(i).getTotalPrice());
                }else if(var.equals("Reason")){
                    return (AllPRData.get(i).getReason());
                }else if(var.equals("Date")){
                    return (AllPRData.get(i).getDate());
                }else if(var.equals("Status")){
                    return (AllPRData.get(i).GetStatus());
                }
            }
        }
        return null;
    }
    
        
    protected String GetData(String var){
        return GetPRData(ReadPRInfo(),this.PRID,this.PR_ItemSupplierID,var);
    }
    
    protected String GetAllData(String var){
        return GetAllPRData(ReadPRInfo(),this.PRID,var);
    }
    
    

    protected ArrayList<PurchaseRequisition> GetPRFromSameSM() {
        ArrayList<PurchaseRequisition> AllPRData = ReadPRInfo();
        ArrayList<PurchaseRequisition> SamePRData = new ArrayList<>();

        for (PurchaseRequisition pr : AllPRData) {
            
            if (pr.getSM().GetUserId().equals(this.getSM().GetUserId())) {
                SamePRData.add(pr);
            }
        }

        return SamePRData;
    }


    
    protected String PRDate(){
        Date date = new Date();
        LocalDateTime now = LocalDateTime.ofInstant(date.toInstant(), java.time.ZoneId.systemDefault());
        String FormattedDate = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        return FormattedDate;
    }
    
    
    private void DeleteArray(ArrayList<PurchaseRequisition> AllPRData) {
     
       for (int i = 0; i < AllPRData.size(); i++) {
            if (AllPRData.get(i).getPRID().equals(this.PRID)&&AllPRData.get(i).GetPR_ItemSupplierID().equals(this.PR_ItemSupplierID)) {
                AllPRData.get(i).SetStatus("Cancelled");
            }
        }
        
        // Write the updated item data back to the file
        SaveData(AllPRData);
    }
    
    protected void Delete() {
       DeleteArray(ReadPRInfo());
    }
    
    private void DeleteFromSameItemIDSupplierID(ArrayList<PurchaseRequisition> AllPRData) {
     
       for (int i = 0; i < AllPRData.size(); i++) {
            if (AllPRData.get(i).getItemID().equals(this.PRItem)&&AllPRData.get(i).getSupplier().GetSupplierId().equals(this.getSupplier().GetSupplierId())) {
                AllPRData.get(i).SetStatus("Cancelled");
            }
        }
        
        // Write the updated item data back to the file
        SaveData(AllPRData);
    }
    
    private void DeleteFromSameSupplierID(ArrayList<PurchaseRequisition> AllPRData) {
     
       for (int i = 0; i < AllPRData.size(); i++) {
            if (AllPRData.get(i).getSupplier().GetSupplierId().equals(this.getSupplier().GetSupplierId())) {
                AllPRData.get(i).SetStatus("Cancelled");
            }
        }
        
        // Write the updated item data back to the file
        SaveData(AllPRData);
    }
    
    private void DeleteFromSameItemID(ArrayList<PurchaseRequisition> AllPRData) {
     
       for (int i = 0; i < AllPRData.size(); i++) {
            if (AllPRData.get(i).getItemID().equals(this.PRItem)) {
                AllPRData.get(i).SetStatus("Cancelled");
            }
        }
        
        // Write the updated item data back to the file
        SaveData(AllPRData);
    }
    
    protected void Delete(String var){
        if(var.equals("ItemID")){
            DeleteFromSameItemID(ReadPRInfo());
        }else if(var.equals("SupplierID")){
            DeleteFromSameSupplierID(ReadPRInfo());
        }else if(var.equals("BothID")){
            DeleteFromSameItemIDSupplierID(ReadPRInfo());
        }
    }
    
    private boolean EditArray(ArrayList<PurchaseRequisition> AllPRData) {
        if(!EditDuplicatedCheck(ReadPRInfo())){
            for (int i = 0; i < AllPRData.size(); i++) {
                if (AllPRData.get(i).getPRID().equals(this.PRID)&&
                        AllPRData.get(i).GetPR_ItemSupplierID().equals(this.PR_ItemSupplierID)) {
                    
                    AllPRData.set(i, this); // Replace the existing object with the updated one
                    break;
                }
            }
            // Write the updated item data back to the file
            SaveData(AllPRData);
            return true;
        }
        return false;

    }
    
    protected boolean Edit() {
       return EditArray(ReadPRInfo());
    }

    
    private boolean ApproveReject(ArrayList<PurchaseRequisition> AllPRData, String status) {
        if(!EditDuplicatedCheck(ReadPRInfo())){
            for (int i = 0; i < AllPRData.size(); i++) {
                if (AllPRData.get(i).getPRID().equals(this.PRID)&&
                        AllPRData.get(i).GetPR_ItemSupplierID().equals(this.PR_ItemSupplierID)) {
                    
                    AllPRData.get(i).SetStatus(status); 
                    break;
                }
            }
            // Write the updated item data back to the file
            SaveData(AllPRData);
            return true;
        }
        return false;

    }
    
    protected boolean EditStatus(String status) {
       return ApproveReject(ReadPRInfo(),status);
    }
    


    private void SaveData(ArrayList<PurchaseRequisition> AllPRData){
        File file = new File("data/PurchaseRequisition.txt");
        // relative file paths

        try {
            // Create a FileWriter object to write to the file
            FileWriter w = new FileWriter(file,false);
            
            
        for (int i = 0; i < AllPRData.size(); i++) {
           // Write the user input to the file
            w.write("PR ID: " + AllPRData.get(i).getPRID() + "\n");
            w.write("PR Line ID: " + AllPRData.get(i).GetPR_ItemSupplierID()+ "\n");
            w.write("Item ID: " + AllPRData.get(i).getItemID()+ "\n");
            w.write("Supplier ID: " + AllPRData.get(i).getSupplier().GetSupplierId()+ "\n");
            w.write("Order Quantity: " + AllPRData.get(i).getOrderQuantity()+ "\n");
            w.write("Required Date: " + AllPRData.get(i).getRequiredDate()+ "\n");
            w.write("Total Price (RM): " + AllPRData.get(i).getTotalPrice()+ "\n");
            w.write("Reason: " + AllPRData.get(i).getReason()+ "\n");
            w.write("SM ID: " + AllPRData.get(i).getSM().GetUserId()+ "\n");
            w.write("Date: " + AllPRData.get(i).getDate()+ "\n");
            w.write("Status: " + AllPRData.get(i).GetStatus()+ "\n\n");
            
        }    
            
            // Close the FileWriter
            w.close();

            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private ArrayList<String[]> CreatePRArray(ArrayList<PurchaseRequisition> AllPRInfo){
        ArrayList<String[]> PRList = new ArrayList<>();
        
        for (int i = 0; i < AllPRInfo.size(); i++){
            String ID;

            ID = AllPRInfo.get(i).getSM().GetUserId();

            String[] pr = new String[]{
                AllPRInfo.get(i).getPRID(),
                AllPRInfo.get(i).GetPR_ItemSupplierID(),
                ID,
                AllPRInfo.get(i).getItemID(),
                AllPRInfo.get(i).getSupplier().GetSupplierId(),
                AllPRInfo.get(i).getOrderQuantity(),
                AllPRInfo.get(i).getTotalPrice(),
                AllPRInfo.get(i).getRequiredDate(),
                AllPRInfo.get(i).getDate(),
                AllPRInfo.get(i).getReason(),
                AllPRInfo.get(i).GetStatus()
            };
            
           
            PRList.add(pr);
        }
        
        return PRList;
    }
    
    public ArrayList<String[]> GetPRDataArray(){
        return CreatePRArray(ReadPRInfo());
    }
    
    private ArrayList<String[]> CreateFilterPRIDPRArray(ArrayList<PurchaseRequisition> AllPRInfo, String PRID){
        ArrayList<String[]> PRList = new ArrayList<>();
        
        for (int i = 0; i < AllPRInfo.size(); i++){
            String ID;

            ID = AllPRInfo.get(i).getSM().GetUserId();

            
            if(!(AllPRInfo.get(i).getPRID().equals(PRID))){
                continue;
            }
            String[] pr = new String[]{
                AllPRInfo.get(i).getPRID(),
                AllPRInfo.get(i).GetPR_ItemSupplierID(),
                ID,
                AllPRInfo.get(i).getItemID(),
                AllPRInfo.get(i).getSupplier().GetSupplierId(),
                AllPRInfo.get(i).getOrderQuantity(),
                AllPRInfo.get(i).getTotalPrice(),
                AllPRInfo.get(i).getRequiredDate(),
                AllPRInfo.get(i).getDate(),
                AllPRInfo.get(i).getReason(),
                AllPRInfo.get(i).GetStatus()
            };
            
            
            PRList.add(pr);
        }
        
        return PRList;
    }
    
    public ArrayList<String[]> GetFilterPRIDPRArray(String PRID){
        return CreateFilterPRIDPRArray(ReadPRInfo(),PRID);
    }
    
     private ArrayList<String[]> CreateFilterStatusPRArray(ArrayList<PurchaseRequisition> AllPRInfo, String Status){
        ArrayList<String[]> PRList = new ArrayList<>();
        
        for (int i = 0; i < AllPRInfo.size(); i++){
            String ID;

            ID = AllPRInfo.get(i).getSM().GetUserId();

            
            if(!(AllPRInfo.get(i).GetStatus().equals(Status))){
                continue;
            }
            String[] pr = new String[]{
                AllPRInfo.get(i).getPRID(),
                AllPRInfo.get(i).GetPR_ItemSupplierID(),
                ID,
                AllPRInfo.get(i).getItemID(),
                AllPRInfo.get(i).getSupplier().GetSupplierId(),
                AllPRInfo.get(i).getOrderQuantity(),
                AllPRInfo.get(i).getTotalPrice(),
                AllPRInfo.get(i).getRequiredDate(),
                AllPRInfo.get(i).getDate(),
                AllPRInfo.get(i).getReason(),
                AllPRInfo.get(i).GetStatus()
            };
            
           
            PRList.add(pr);
        }
        
        return PRList;
    }
    
    public ArrayList<String[]> GetFilterStatusPRArray(String Status){
        return CreateFilterStatusPRArray(ReadPRInfo(),Status);
    }
    
    //check for Item ID
    private boolean DuplicatedCheck(ArrayList<PurchaseRequisition> AllPRInfo){
        for(PurchaseRequisition APR: AllPRInfo){
            if(APR.getItemID().equals(this.getItemID()) && APR.GetStatus().equals("Pending")){
                return true;
            }
            
        }
        return false;
    }
    
    //check for item id - editSyste
    private boolean EditDuplicatedCheck(ArrayList<PurchaseRequisition> AllPRInfo){
        for(PurchaseRequisition APR: AllPRInfo){
            if(APR.getPRID().equals(this.PRID) && APR.GetPR_ItemSupplierID().equals(this.PR_ItemSupplierID)){
                return false;
            }else if(APR.getItemID().equals(this.getItemID()) && APR.GetStatus().equals("Pending")){
                return true;
            }
            
        }
        return false;
    }
    
    private boolean StatusCheck(ArrayList<PurchaseRequisition> AllPRInfo){
        for(PurchaseRequisition APR: AllPRInfo){
            if(APR.getPRID().equals(this.PRID) && APR.GetStatus().equals("Pending")){
                return true;
            }
        }
        return false;
    }
    
    protected boolean StatusCheck(){
        return StatusCheck(ReadPRInfo());
    }
    
    private String[] GetFilterPRID(ArrayList<PurchaseRequisition> AllPRInfo) {
        HashSet<String> PRIDSet = new HashSet<>();

        for (PurchaseRequisition APR : AllPRInfo) {
            String PRID = APR.getPRID();
            PRIDSet.add(PRID);
        }
        String[] UniquePRID = PRIDSet.toArray(new String[0]);

        return UniquePRID;
    }
    
    public String[] GetFilterPRIDs(){
        return GetFilterPRID(ReadPRInfo());
    }
    
    private String[] GetFilterStatus(ArrayList<PurchaseRequisition> AllPRInfo) {
        HashSet<String> StatusSet = new HashSet<>();

        for (PurchaseRequisition APR : AllPRInfo) {
            String Status = APR.GetStatus();
            StatusSet.add(Status);
        }
        String[] UniqueStatus = StatusSet.toArray(new String[0]);

        return UniqueStatus;
    }
    
    public String[] GetFilterStatuss(){
        return GetFilterStatus(ReadPRInfo());
    }
    
   
}
