/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sigma.sdn.bhd;

//auto generate item code

import java.awt.List;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;


public class Item extends DataCheck{
    //aggregation to supplier class
    
    protected String ItemId;
    private String ItemName;
    private String ItemPrice;
    private double DoubleItemPrice = 0;
    private Supplier supplier;
    private String ItemStatus;
    private Stock stock;
    
    public Item(String ItemId, String ItemName, String ItemPrice, Supplier supplier, String status){
       super();
       this.ItemId = ItemId;
       this.ItemName = ItemName;
       this.ItemPrice = ItemPrice;
       this.supplier = supplier;
       this.ItemStatus = status;
       this.stock = new Stock(ItemId);
   }
    
    public Item(String ItemName, String ItemPrice, Supplier supplier){
       super();
       this.ItemId = GenerateItemId(ReadItemData());
       this.ItemName = ItemName;
       this.ItemPrice = ItemPrice;
       this.supplier = supplier;
       this.stock = new Stock();
   }
    
    public Item(String ItemId, Supplier supplier){
       super();
       this.ItemId = ItemId;
       this.supplier = supplier;
       this.stock = new Stock(ItemId);
   }
    
    
    public Item(Supplier supplier){
        super();
        this.supplier = supplier;
        this.stock = new Stock();
    }
    
    public Item(String ItemId){
        super();
        //for search item only
        this.ItemId = ItemId;
        this.stock = new Stock(ItemId);
    }
    
    public Item(){
        super();
        //for view item only
    }
    
    protected void SetItemID(String ItemId){
        this.ItemId = ItemId;
        this.stock = new Stock(ItemId);
    }
    
    protected void SetItemName(String ItemName){
        this.ItemName = ItemName;
    }
    
     protected void SetItemStatus(String ItemStatus){
        this.ItemStatus = ItemStatus;
    }
    
    
    protected void SetItemPrice(String ItemPrice){
        this.ItemPrice = ItemPrice;
    }
    
    protected void SetSupplier(Supplier supplier){
        this.supplier = supplier;
    }

    public Supplier GetSupplier() {
        return supplier;
    }
    
   protected String GetItemId(){
        return this.ItemId;
    }
    
    protected String GetItemName(){
        return this.ItemName;
    }
    
    protected String GetItemPrice(){
        return this.ItemPrice;
    }
    
    protected String GetItemStatus(){
        return this.ItemStatus;
    }
    
    protected String GetSupplierCode(){
        return this.supplier.GetSupplierId();
    }
    
    protected String GetExpectedDelivery(){
        return this.supplier.GetData("Expected Delivery Time(days)");
    }
    

    protected String getItemIDFromName(String ItemName){
       return GetItemData(ReadItemData(), ItemName);
    }
    
    protected String CheckInput() {
        if (this.ItemName.isEmpty() || this.ItemPrice.isEmpty() || GetSupplierCode().isEmpty()) {
            return "Incomplete";
        } else {
            try {
                DoubleItemPrice = Double.parseDouble(this.ItemPrice);
                return "Correct";
            } catch (NumberFormatException e) {
                return "Not Double";
            }
        }
    }
    
    
    protected boolean CheckDuplicateSupplierWithItem(){
        if(GetData("Item Name",GetSupplierCode())== null){
            return true;
        }
        return false;
    }

    protected ArrayList<Item> ReadItemData() {

        // Create a new file object to read from
        File ItemDataFile = new File("data/ItemInfo.txt");

        // Create an ArrayList to store the customer data
        ArrayList<Item> AllItemData = new ArrayList<>();


        try {
            // Create a new Scanner object to read from the file
            Scanner scanner = new Scanner(ItemDataFile);
            
            Item ReadItem;
            // Read each line of the file
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();

                if (!line.trim().isEmpty()) {
                    String itemid = line.split(":")[1].trim();
                    String itemname = scanner.nextLine().split(":")[1].trim();
                    String itemprice = scanner.nextLine().split(":")[1].trim();
                    String supplierid = scanner.nextLine().split(":")[1].trim();
                    String status = scanner.nextLine().split(":")[1].trim();
                    
                    ReadItem = new Item(itemid,itemname,itemprice,new Supplier(supplierid),status);
                    AllItemData.add(ReadItem);
                }else{
                    ReadItem = null;
                    continue;
                }
               
            }
          // Close the scanner
            scanner.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        return AllItemData;
    }

    private String GenerateItemId(ArrayList<Item> AllItemData) {
        int maxID = 0;
        
        for (int i = 0;i < AllItemData.size();i++) {
            String ItemId = AllItemData.get(i).GetItemId();
            int ItemIdInt = Integer.parseInt(ItemId.substring(1));
            if (ItemIdInt > maxID) {
                maxID = ItemIdInt;
            }
        }

        // Generate the new item ID
        String NewItemId = "I" + (maxID + 1);

        return NewItemId;
    }

    
    protected void AddItem(){
        File file = new File("data/ItemInfo.txt");
        // relative file paths

        try {
            // Create a FileWriter object to write to the file
            FileWriter writer = new FileWriter(file,true);
            
            this.ItemPrice = String.format("%.2f", DoubleItemPrice);
            
            
            // Write the user input to the file
            writer.write("Item Id: "+ this.ItemId + "\n");
            writer.write("Item Name: " + this.ItemName + "\n");
            writer.write("Item Price(RM): " + this.ItemPrice + "\n");
            writer.write("Supplier Id: " + GetSupplierCode() + "\n");
            writer.write("Status: A" + "\n\n");

            // Close the FileWriter
            writer.close();

            
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        stock.AddItemToStock(this.ItemId);
        
    }
    
    
    protected void AddtoExistingItem(){
        File file = new File("data/ItemInfo.txt");
        // relative file paths

        try {
            // Create a FileWriter object to write to the file
            FileWriter writer = new FileWriter(file,true);
            
            this.ItemPrice = String.format("%.2f", DoubleItemPrice);

            // Write the user input to the file
            writer.write("Item Id: "+ this.ItemId + "\n");
            writer.write("Item Name: " + this.ItemName + "\n");
            writer.write("Item Price(RM): " + this.ItemPrice + "\n");
            writer.write("Supplier Id: " + GetSupplierCode() + "\n");
            writer.write("Status: A\n\n");

            // Close the FileWriter
            writer.close();

            
        } catch (IOException e) {
            e.printStackTrace();
        }
       
    }
     
    protected String GetItemData(ArrayList<Item> AllItemData, String ItemID, String var){
        int size = AllItemData.size();
        for(int i=0;i<size;i++){
            if(AllItemData.get(i).GetItemId().equals(ItemID)){
                if(var.equals("Item Name")){
                    return (AllItemData.get(i).GetItemName());
                }else if(var.equals("Item Price(RM)")){
                    return (AllItemData.get(i).GetItemPrice());
                }else if(var.equals("Supplier Id")){
                    return (AllItemData.get(i).GetSupplierCode());
                }else if(var.equals("Status")){
                    return (AllItemData.get(i).GetItemStatus());
                }
            }
        }
        return null;
    }
    
    private String GetItemData(ArrayList<Item> AllItemData, String ItemID, String SupplierId, String var){
        int size = AllItemData.size();
        for(int i=0;i<size;i++){
            if(AllItemData.get(i).GetItemId().equals(ItemID) && AllItemData.get(i).GetSupplierCode().equals(SupplierId)){
                if(var.equals("Item Name")){
                    return (AllItemData.get(i).GetItemName());
                }else if(var.equals("Item Price(RM)")){
                    return (AllItemData.get(i).GetItemPrice());
                }else if(var.equals("Status")){
                    return (AllItemData.get(i).GetItemStatus());
                }
            }
        }
        return null;
    }
    
    private String GetItemData(ArrayList<Item> AllItemData, String ItemName){
        int size = AllItemData.size();
        for(int i=0;i<size;i++){
            if(AllItemData.get(i).GetItemName().equals(ItemName)){
                return (AllItemData.get(i).GetItemId());
            }
        }
        return null;
    }
    
    private String[] GetSupplierIDList(ArrayList<Item> AllItemData, String ItemID) {
        ArrayList<String> supplierIDArrayList = new ArrayList<>();
        int size = AllItemData.size();

        for (int i = 0; i < size; i++) {
            if (AllItemData.get(i).GetItemId().equals(ItemID)) {
                if(AllItemData.get(i).GetItemStatus().equals("A")){
                    String supplierID = AllItemData.get(i).GetSupplierCode();
                    supplierIDArrayList.add(supplierID);
                }
            }
        }

        // Convert the ArrayList to an array of Strings
        String[] supplierIDList = new String[supplierIDArrayList.size()];
        supplierIDList = supplierIDArrayList.toArray(supplierIDList);

        return supplierIDList;
    }
    
    private String[] GetFilterSupplierID(ArrayList<Item> AllItemData) {
    HashSet<String> supplierIDSet = new HashSet<>();

        for (Item item : AllItemData) {
            String supplierID = item.GetSupplierCode();
            supplierIDSet.add(supplierID);
        }
        String[] UniqueSID = supplierIDSet.toArray(new String[0]);

        return UniqueSID;
    }
    
    private String[] GetFilterItemID(ArrayList<Item> AllItemData) {
    HashSet<String> ItemIDSet = new HashSet<>();

        for (Item item : AllItemData) {
            String itemID = item.GetItemId();
            ItemIDSet.add(itemID);
        }
        String[] UniqueSID = ItemIDSet.toArray(new String[0]);

        return UniqueSID;
    }


    
    private String[] GetItemNameList(ArrayList<Item> AllItemData) {
        ArrayList<String> ItemNameArrayList = new ArrayList<>();
        int size = AllItemData.size();

        for (int i = 0; i < size; i++) {
            
            ItemNameArrayList.add(AllItemData.get(i).GetItemName());
            
        }

        // Convert the ArrayList to an array of Strings
        String[] ItemNameList = new String[ItemNameArrayList.size()];
        ItemNameList = ItemNameArrayList.toArray(ItemNameList);

        return ItemNameList;
    }

    protected boolean DuplicatedCheck(){
        for(int i = 0;i<GetItemNameList(ReadItemData()).length;i++){
            if (this.ItemName.equalsIgnoreCase(GetItemNameList(ReadItemData())[i])){
                return true;
            }
        }
        return false;
    }

    
    protected String GetData(String var){
        return GetItemData(ReadItemData(),this.ItemId,var);
    }
    
    protected String GetData(String var,String SupplierId){
        return GetItemData(ReadItemData(),this.ItemId,SupplierId,var);
    }
    
    
    protected String[] GetSupplierIDs(){
        return GetSupplierIDList(ReadItemData(),this.ItemId);
    }
    
    protected String[] GetFilteredSupplierIDs(){
        return GetFilterSupplierID(ReadItemData());
    }
    
     protected String[] GetFilteredItemIDs(){
        return GetFilterItemID(ReadItemData());
    }
     
    private boolean CheckItemId(ArrayList<Item> AllItemData){
        int size = AllItemData.size();

        for (int i = 0; i < size; i++) {
            if(AllItemData.get(i).GetItemId().equals(this.ItemId) && AllItemData.get(i).GetItemStatus().equals("A")){
                return true;
            }
        }
        return false;
    } 
    
    protected boolean CheckItemIds(){
        return CheckItemId(ReadItemData());
    } 
    
    private boolean CheckItemId(ArrayList<Item> AllItemData, String ITEMID){
        int size = AllItemData.size();

        for (int i = 0; i < size; i++) {
            if(AllItemData.get(i).GetItemId().equals(ITEMID) && AllItemData.get(i).GetItemStatus().equals("A")){
                return true;
            }
        }
        
        return false;
    } 
    
    protected void EditItemPrice(){
        EditItemPriceArray(ReadItemData());
    }
    
    protected void EditItemName(){
        EditItemNameArray(ReadItemData());
    }
    
    protected void DeleteItemFromAllSupplier(){
        DeleteItemArray(ReadItemData());
    }
    
    protected void DeleteItemFromOneSupplier(){
        DeleteOneItemFromOneSupplier(ReadItemData());
    }
    
    protected void DeleteItemsFromOneSupplier(String SPID){
        DeleteItemArray(ReadItemData(),SPID);
    }
    
    private void EditItemPriceArray(ArrayList<Item> AllItemData) {
        // Find item ID using for loop
        this.ItemPrice = String.format("%.2f", DoubleItemPrice);
        for (int i = 0; i < AllItemData.size(); i++) {
            if (AllItemData.get(i).GetItemId().equals(this.ItemId) && AllItemData.get(i).GetSupplierCode().equals(this.GetSupplierCode())) {
                
                AllItemData.get(i).SetItemPrice(this.ItemPrice);
                break; 
            }
        }
        // Write the updated item data back to the file
        SaveData(AllItemData);
    }
    
    private void EditItemNameArray(ArrayList<Item> AllItemData) {
        for (int i = 0; i < AllItemData.size(); i++) {
            if (AllItemData.get(i).GetItemId().equals(this.ItemId)) {
                AllItemData.get(i).SetItemName(this.ItemName);
            }
        }

        // Write the updated item data back to the file
        SaveData(AllItemData);
    }
    
    
    //delete item id
    private void DeleteItemArray(ArrayList<Item> AllItemData) {
        Iterator<Item> ItemIterator = AllItemData.iterator();

        while (ItemIterator.hasNext()) {
            Item currentItem = ItemIterator.next();
            if (currentItem.GetItemId().equals(this.ItemId)) {
                currentItem.SetItemStatus("NA");
            }
        }

        // Write the updated item data back to the file
        SaveData(AllItemData);
        
        PurchaseRequisition DeletePR = new PurchaseRequisition(new Item());
        DeletePR.SetItemID(this.ItemId);
        DeletePR.Delete("ItemID");

        stock.SetStockStatus("NA");
        stock.DeleteItemFromStock();
    }
    

    protected void DeleteItemFromStock(){
        stock.SetStockStatus("NA");
        stock.DeleteItemFromStock();
    }
    
    
     //traditional cascading
    //delete supplier id and item id
    private void DeleteOneItemFromOneSupplier(ArrayList<Item> AllItemData) {
       
        for (int i = 0; i < AllItemData.size(); i++) {
            if (AllItemData.get(i).GetItemId().equals(this.ItemId) && AllItemData.get(i).GetSupplierCode().equals(this.GetSupplierCode())) {
                AllItemData.get(i).SetItemStatus("NA");
                break;
            }
        }
        PurchaseRequisition DeletePR = new PurchaseRequisition(new Item());
        DeletePR.SetItemID(this.ItemId);
        DeletePR.setSupplier(new Supplier(this.GetSupplierCode()));
        DeletePR.Delete("BothID");
        // Write the updated item data back to the file
        SaveData(AllItemData);
        if(!CheckItemId(ReadItemData())){
            stock.SetItemID(this.ItemId);
            stock.SetStockStatus("NA");
            stock.DeleteItemFromStock();
        }
    }
    
    
    
    //delete supplier id
    private void DeleteItemArray(ArrayList<Item> AllItemData, String SupplierId) {
       
        
        for (int i = 0; i < AllItemData.size(); i++) {
            if (AllItemData.get(i).GetSupplierCode().equals(SupplierId)) {
                AllItemData.get(i).SetItemStatus("NA");
                
                if(!(CheckItemId(AllItemData,AllItemData.get(i).GetItemId())) ){
                    Stock DeleteStock = new Stock(AllItemData.get(i).GetItemId());
                    DeleteStock.SetItemID(AllItemData.get(i).GetItemId());
                    DeleteStock.SetStockStatus("NA");
                    DeleteStock.DeleteItemFromStock();
                }
            }
        }
        PurchaseRequisition DeletePR = new PurchaseRequisition(new Item());
        DeletePR.setSupplier(new Supplier(this.GetSupplierCode()));
        DeletePR.Delete("SupplierID");
        
        // Write the updated item data back to the file
        SaveData(AllItemData);
    }
    
    private void SaveData(ArrayList<Item> AllItemData){
        File file = new File("data/ItemInfo.txt");
        // relative file paths

        try {
            // Create a FileWriter object to write to the file
            FileWriter writer = new FileWriter(file,false);
            
            
        for (int i = 0; i < AllItemData.size(); i++) {
           // Write the user input to the file
            writer.write("Item Id: "+ AllItemData.get(i).GetItemId() + "\n");
            writer.write("Item Name: " + AllItemData.get(i).GetItemName() + "\n");
            writer.write("Item Price(RM): " + AllItemData.get(i).GetItemPrice()  + "\n");
            writer.write("Supplier Id: " + AllItemData.get(i).GetSupplierCode() + "\n");
            writer.write("Status: " + AllItemData.get(i).GetItemStatus()+ "\n\n");
        }    
            
            // Close the FileWriter
            writer.close();

            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
    
    private ArrayList<String[]> CreateItemArray(ArrayList<Item> AllItemData){
        ArrayList<String[]> ItemList = new ArrayList<>();

        for (int i = 0; i < AllItemData.size(); i++) {
            
            String[] Item = new String[]{
                AllItemData.get(i).GetItemId(),
                AllItemData.get(i).GetItemName(),
                AllItemData.get(i).GetItemPrice(),
                AllItemData.get(i).GetSupplierCode(),
                AllItemData.get(i).GetItemStatus()
            };
            ItemList.add(Item);
        }

        return ItemList;
    }
    
    private ArrayList<String[]> CreateFilterSIDItemArray(ArrayList<Item> AllItemData, String SID){
        ArrayList<String[]> ItemList = new ArrayList<>();

        for (int i = 0; i < AllItemData.size(); i++) {
            if(AllItemData.get(i).GetSupplierCode().equals(SID)){
                String[] Item = new String[]{
                AllItemData.get(i).GetItemId(),
                AllItemData.get(i).GetItemName(),
                AllItemData.get(i).GetItemPrice(),
                AllItemData.get(i).GetSupplierCode(),
                AllItemData.get(i).GetItemStatus()
                };
                ItemList.add(Item);
            }
            
        }

        return ItemList;
    }
    
    private ArrayList<String[]> CreateFilterItemIDItemArray(ArrayList<Item> AllItemData, String ItemID){
        ArrayList<String[]> ItemList = new ArrayList<>();

        for (int i = 0; i < AllItemData.size(); i++) {
            if(AllItemData.get(i).GetItemId().equals(ItemID)){
                String[] Item = new String[]{
                AllItemData.get(i).GetItemId(),
                AllItemData.get(i).GetItemName(),
                AllItemData.get(i).GetItemPrice(),
                AllItemData.get(i).GetSupplierCode(),
                AllItemData.get(i).GetItemStatus()
                };
                ItemList.add(Item);
            }
            
        }

        return ItemList;
    }
    
    private ArrayList<String[]> CreatePRItemArray(ArrayList<Item> AllItemData, String Itemid){
        ArrayList<String[]> ItemList = new ArrayList<>();

        for (int i = 0; i < AllItemData.size(); i++) {
            if(AllItemData.get(i).GetItemId().equals(Itemid)){
                Supplier ViewSupplier = new Supplier(AllItemData.get(i).GetSupplierCode());
                AllItemData.get(i).SetSupplier(ViewSupplier);
                String[] Item = new String[]{
                    AllItemData.get(i).GetItemId(),
                    AllItemData.get(i).GetItemName(),
                    AllItemData.get(i).GetSupplierCode(),
                    AllItemData.get(i).GetItemPrice(),
                    AllItemData.get(i).GetItemStatus(),
                    String.valueOf(AllItemData.get(i).GetExpectedDelivery())
                };
                ItemList.add(Item);
            }
            
        }

        return ItemList;
    }
    
    protected ArrayList<String[]> GetItemDataArray(){
        return CreateItemArray(ReadItemData());
    }
    
    protected ArrayList<String[]> GetFilterSIDItemDataArray(String SID){
        return CreateFilterSIDItemArray(ReadItemData(), SID);
    }
    
    protected ArrayList<String[]> GetFilterItemIDItemDataArray(String ItemID){
        return CreateFilterItemIDItemArray(ReadItemData(), ItemID);
    }
    
    protected ArrayList<String[]> GetPRItemArray(String Itemid){
        return CreatePRItemArray(ReadItemData(), Itemid);
    }

    private String[] GetAllItemID(ArrayList<Item> AllItemData) {
        HashSet<String> UniqueItemIDs = new HashSet<>();

        for (Item item : AllItemData) {
            if(item.GetItemStatus().equals("A")){
                String itemID = item.GetItemId();
                UniqueItemIDs.add(itemID);
            }
            
        }

        // Convert the HashSet to an array of Strings
        String[] itemIDList = new String[UniqueItemIDs.size()];
        UniqueItemIDs.toArray(itemIDList);

        return itemIDList;
    }
    
    
    protected String[] GetAllItemIDs(){
        return GetAllItemID(ReadItemData());
    }
    
    private String[] GetAllLowStockItemID(ArrayList<Item> AllItemData) {
        HashSet<String> UniqueItemIDs = new HashSet<>();
        
        for (Item item : AllItemData) {
            Stock ViewStock = new Stock(item.GetItemId());
            if(item.GetItemStatus().equals("A") && (Integer.parseInt(ViewStock.GetData("Stock Quantity")) <=
                    Integer.parseInt(ViewStock.GetData("Reorder Level")))){
                String itemID = item.GetItemId();
                UniqueItemIDs.add(itemID);
            }
            
        }

        // Convert the HashSet to an array of Strings
        String[] itemIDList = new String[UniqueItemIDs.size()];
        UniqueItemIDs.toArray(itemIDList);

        return itemIDList;
    }
    
    
    protected String[] GetAllLowStockItemIDs(){
        return GetAllLowStockItemID(ReadItemData());
    }
    
   //difference between toString and fromString
   public String toString(){
       return "Item ID=" + ItemId + " Item Name=" + ItemName + " Item Price="+ItemPrice +"\n"+ supplier.toString();
   }

    


}
