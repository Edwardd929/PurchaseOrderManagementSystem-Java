/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sigma.sdn.bhd;

/**
 *
 * @author vinni
 */
public abstract class DataCheck {
   
    public DataCheck(){
    }
    protected abstract String CheckInput();
    protected abstract boolean DuplicatedCheck();
    protected abstract String GetData(String var);
    public abstract String toString();

}
