/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sigma.sdn.bhd;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;


public class Supplier extends DataCheck{
    private String SupplierId;
    private String SupplierName;
    private String SupplierAddress;
    private int ExpectedDelivery;
    private String status;


    //create supplier
    public Supplier(String SupplierId, String SupplierName, String SupplierAddress, int ExpectedDelivery, String status){
       super();
       this.SupplierId = SupplierId;
       this.SupplierName = SupplierName;
       this.SupplierAddress = SupplierAddress;
       this.ExpectedDelivery = ExpectedDelivery;
       this.status = status;
       
   }
    
    public Supplier(String SupplierName, String SupplierAddress, int ExpectedDelivery){
       super();
       this.SupplierName = SupplierName;
       this.SupplierAddress = SupplierAddress;
       this.ExpectedDelivery = ExpectedDelivery;
   }
    
    public Supplier(String SupplierId){
        super();
        this.SupplierId = SupplierId;
    }
    
    
    public Supplier(){
        super();
        //for view supplier only
    }
    
    protected String GetSupplierId(){
        return this.SupplierId;
    }
    
    protected String GetSupplierName(){
        return this.SupplierName;
    }
    
    protected String GetSupplierStatus(){
        return this.status;
    }
    
    protected void SetSupplierStatus(String status){
        this.status = status;
    }
    
    protected String GetSupplierAddress(){
        return this.SupplierAddress;
    }
    
    protected int GetExpectedDelivery(){
        return this.ExpectedDelivery;
    }
    
    protected void SetSupplierId(String SupplierId){
        this.SupplierId = SupplierId;
    }
    
    protected void SetSupplierName(String SupplierName){
        this.SupplierName = SupplierName;
    }
    
    protected void SetSupplierAddress(String SupplierAddress){
        this.SupplierAddress = SupplierAddress;
    }
    
    protected void SetExpectedDelivery(int ExpectedDelivery){
        this.ExpectedDelivery = ExpectedDelivery;
    }
    
    protected String CheckInput() {
        String ExpectedDeliveryStr;
        ExpectedDeliveryStr =  String.valueOf(this.ExpectedDelivery);
        if (this.SupplierName.isEmpty() || this.SupplierAddress.isEmpty() || ExpectedDeliveryStr.isEmpty()) {
            return "Incomplete";
        } else if(DuplicatedCheck()){
            return "Duplicated";
        }else {
            return "Correct";
        }
    }

    protected boolean DuplicatedCheck(){
        for(int i = 0;i<GetSupplierNameList(ReadSupplierData()).length;i++){
            if (this.SupplierName.equalsIgnoreCase(GetSupplierNameList(ReadSupplierData())[i])){
                return true;
            }
        }
        return false;
    }
    
    private String[] GetSupplierNameList(ArrayList<Supplier> AllSupplierData) {
        ArrayList<String> SupplierNameArrayList = new ArrayList<>();
        int size = AllSupplierData.size();

        for (int i = 0; i < size; i++) {
            SupplierNameArrayList.add(AllSupplierData.get(i).GetSupplierName()); 
        }

        // Convert the ArrayList to an array of Strings
        String[] SupplierNameList = new String[SupplierNameArrayList.size()];
        SupplierNameList = SupplierNameArrayList.toArray(SupplierNameList);

        return SupplierNameList;
    }
    
    private ArrayList<Supplier> ReadSupplierData() {

        // Create a new file object to read from
        File SupplierDataFile = new File("data/SupplierInfo.txt");

        // Create an ArrayList to store the customer data
        ArrayList<Supplier> AllSupplierData = new ArrayList<>();


        try {
            // Create a new Scanner object to read from the file
            Scanner scanner = new Scanner(SupplierDataFile);
            
            Supplier ReadSupplier;
            // Read each line of the file
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();

                if (!line.trim().isEmpty()) {
                    String supplierid = line.split(":")[1].trim();
                    String suppliername = scanner.nextLine().split(":")[1].trim();
                    String supplieraddress = scanner.nextLine().split(":")[1].trim();
                    String expected = scanner.nextLine().split(":")[1].trim();
                    int expecteddays = Integer.parseInt(expected);
                    String status = scanner.nextLine().split(":")[1].trim();
                    
                    ReadSupplier = new Supplier(supplierid,suppliername,supplieraddress,expecteddays,status);
                    AllSupplierData.add(ReadSupplier);
                }else{
                    ReadSupplier = null;
                    continue;
                }
                
            }
            // Close the scanner
            scanner.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        return AllSupplierData;
    }
    
    private String GenerateSupplierId(ArrayList<Supplier> AllSupplierData) {
        
        String LastSupplierId = AllSupplierData.get(AllSupplierData.size()-1).GetSupplierId();

        // Extract the number from the last item ID

        int LastSupplierIdInt = Integer.parseInt(LastSupplierId.substring(2));

        // Generate the new item ID
        String NewSupplierId = "SU" + (LastSupplierIdInt + 1);

        return NewSupplierId;
    }
    

    
    protected void AddSupplier(){
        File file = new File("data/SupplierInfo.txt");
        // relative file paths

        try {
            // Create a FileWriter object to write to the file
            FileWriter writer = new FileWriter(file,true);
            
            this.SupplierId = GenerateSupplierId(ReadSupplierData());
            
            // Write the user input to the file
            writer.write("Supplier Id: "+ this.SupplierId + "\n");
            writer.write("Supplier Name: " + this.SupplierName + "\n");
            writer.write("Supplier Address: " + this.SupplierAddress + "\n");
            writer.write("Expected Delivery Time(days): " + this.ExpectedDelivery + "\n");
            writer.write("Status: A\n\n");

            // Close the FileWriter
            writer.close();

            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private String GetSupplierData(ArrayList<Supplier> AllSupplierData, String SupplierID, String var){
        int size = AllSupplierData.size();
        for(int i=0;i<size;i++){
            if(AllSupplierData.get(i).GetSupplierId().equals(SupplierID)){
                if(var.equals("Supplier Name")){
                    return (AllSupplierData.get(i).GetSupplierName());
                }else if(var.equals("Supplier Address")){
                    return (AllSupplierData.get(i).GetSupplierAddress());
                }else if(var.equals("Expected Delivery Time(days)")){
                    return (String.valueOf(AllSupplierData.get(i).GetExpectedDelivery()));
                }else if(var.equals("Status")){
                    return (String.valueOf(AllSupplierData.get(i).GetSupplierStatus()));
                }
            }
        }
        return null;
    }
    
    protected String GetData(String var){
        return GetSupplierData(ReadSupplierData(),this.SupplierId,var);
    }
    
    protected boolean CheckSupplierId(){
        if(GetSupplierData(ReadSupplierData(),this.SupplierId,"Supplier Name") != null){
            return true;
        }
        return false;
    } 
    
    protected void EditSupplier(){
        EditSupplierArray(ReadSupplierData());
    }
    
    protected void DeleteSupplier(){
        DeleteSupplierArray(ReadSupplierData());
    }
    
    private void EditSupplierArray(ArrayList<Supplier> AllSupplierData) {
        // Find item ID using for loop
        for (int i = 0; i< AllSupplierData.size();i++) {
            if (AllSupplierData.get(i).GetSupplierId().equals(this.SupplierId)) {
                // Change the key-value with new values
                AllSupplierData.get(i).SetSupplierName(this.SupplierName);
                AllSupplierData.get(i).SetSupplierAddress(this.SupplierAddress);
                AllSupplierData.get(i).SetExpectedDelivery(this.ExpectedDelivery);
                break; 
            }
        }

        // Write the updated item data back to the file
        SaveData(AllSupplierData);
    }
    
    private void SaveData(ArrayList<Supplier> AllSupplierData){
        File file = new File("data/SupplierInfo.txt");
        // relative file paths

        try {
            // Create a FileWriter object to write to the file
            FileWriter writer = new FileWriter(file,false);
            
            
        for (int i = 0; i< AllSupplierData.size();i++) {
           // Write the user input to the file
            writer.write("Supplier Id: "+ AllSupplierData.get(i).GetSupplierId() + "\n");
            writer.write("Supplier Name: " + AllSupplierData.get(i).GetSupplierName() + "\n");
            writer.write("Supplier Address: " + AllSupplierData.get(i).GetSupplierAddress() + "\n");
            writer.write("Expected Delivery Time(days): " + AllSupplierData.get(i).GetExpectedDelivery() + "\n");
            writer.write("Status: " + AllSupplierData.get(i).GetSupplierStatus()+ "\n\n");
        }    
            
            // Close the FileWriter
            writer.close();

            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    private ArrayList<String[]> CreateSupplierArray(ArrayList<Supplier> AllSupplierData){
        ArrayList<String[]> SupplierList = new ArrayList<>();

        for (int i = 0; i< AllSupplierData.size();i++) {
            String[] Supplier = new String[]{
                AllSupplierData.get(i).GetSupplierId(),
                AllSupplierData.get(i).GetSupplierName(),
                AllSupplierData.get(i).GetSupplierAddress(),
                String.valueOf(AllSupplierData.get(i).GetExpectedDelivery()),
                AllSupplierData.get(i).GetSupplierStatus()
            };
            SupplierList.add(Supplier);
        }

        return SupplierList;
    }
    
    protected ArrayList<String[]> GetSupplierDataArray(){
        return CreateSupplierArray(ReadSupplierData());
    }
    
    private ArrayList<String[]> CreateSupplierArray(ArrayList<Supplier> AllSupplierData, String Status){
        ArrayList<String[]> SupplierList = new ArrayList<>();

        for (int i = 0; i< AllSupplierData.size();i++) {
            if(AllSupplierData.get(i).GetSupplierStatus().equals(Status)){
                String[] Supplier = new String[]{
                    AllSupplierData.get(i).GetSupplierId(),
                    AllSupplierData.get(i).GetSupplierName(),
                    AllSupplierData.get(i).GetSupplierAddress(),
                    String.valueOf(AllSupplierData.get(i).GetExpectedDelivery()),
                    AllSupplierData.get(i).GetSupplierStatus()
                };
                SupplierList.add(Supplier);
            }
        }

        return SupplierList;
    }
    
    protected ArrayList<String[]> GetSupplierDataArray(String Status){
        return CreateSupplierArray(ReadSupplierData(), Status);
    }
    
    private String[] GetAllSupplierID(ArrayList<Supplier> AllSupplierData) {
        ArrayList<String> supplierIDArrayList = new ArrayList<>();
        int size = AllSupplierData.size();

        for (int i = 0; i < size; i++) {
            if(AllSupplierData.get(i).GetSupplierStatus().equals("A")){
                String supplierID = AllSupplierData.get(i).GetSupplierId();
                supplierIDArrayList.add(supplierID);
            }
        }

        // Convert the ArrayList to an array of Strings
        String[] supplierIDList = new String[supplierIDArrayList.size()];
        supplierIDList = supplierIDArrayList.toArray(supplierIDList);

        return supplierIDList;
    }
    
    
    protected String[] GetAllSupplierIDs(){
        return GetAllSupplierID(ReadSupplierData());
    }
    
    private void DeleteSupplierArray(ArrayList<Supplier> AllSupplierData) {
       
        // Find the SUPPLIER ID)
        for (int i = 0; i< AllSupplierData.size();i++) {
            if (AllSupplierData.get(i).GetSupplierId().equals(this.SupplierId)) {
                AllSupplierData.get(i).SetSupplierStatus("NA");
                break; 
            }
        }

        // Write the updated item data back to the file
        SaveData(AllSupplierData);
        
        setSupplierStatus(this.SupplierId);
        
    }
    
    private void setSupplierStatus(String SupplierId){
        Item DeleteItem = new Item(new Supplier(SupplierId));
        DeleteItem.DeleteItemsFromOneSupplier(SupplierId);
    }
    

    
    
   //difference between toString and fromString
   public String toString(){
       return "Supplier ID=" + this.SupplierId + " Supplier Name=" + this.SupplierName +  "Supplier Address="+ this.SupplierAddress + "Expected Delivery Time(days)="+this.ExpectedDelivery;
   }
    
}
