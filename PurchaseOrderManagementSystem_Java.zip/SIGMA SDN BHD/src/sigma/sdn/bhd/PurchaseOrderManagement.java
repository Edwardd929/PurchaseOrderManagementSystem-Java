/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package sigma.sdn.bhd;

import java.util.ArrayList;

/**
 *
 * @author vinni
 */
public interface PurchaseOrderManagement {
    String[] GetPSIDFromSamePOs();
    String[] GetFilterPOIDs();
    
    ArrayList<PurchaseOrder> GetPOFromSamePM();
    ArrayList<String[]> GetPODataArray();
    ArrayList<String[]> GetFilterPOIDPRArray(String POID);
    ArrayList<String[]> GetFilterStatusPOArray(String Status);
    
    
}
