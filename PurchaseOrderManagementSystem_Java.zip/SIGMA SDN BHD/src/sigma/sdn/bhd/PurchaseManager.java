/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sigma.sdn.bhd;

import java.util.ArrayList;

/**
 *
 * @author vinni
 */
public class PurchaseManager extends User{
    
    private String PMID;
    public PurchaseManager(String PMID){
        super(PMID);
    }
    
    protected String getPMID(){
        return super.GetUserId();
    }
    
    protected void setSMID(String PMID) {
        super.SetUserId(PMID);
    }
    
    @Override
    protected ArrayList<String> GetAllUserId() {
        
        ArrayList<User> AllCustomerData = super.ReadUserData();
        
        ArrayList<String> PMUserIdList = new ArrayList<>();

        for (int i=0;i<AllCustomerData.size();i++) {
            if(AllCustomerData.get(i).GetRole().equals("Purchase Manager")){
                String UserId = AllCustomerData.get(i).GetUserId();
                PMUserIdList.add(UserId);
            }
        }
        return PMUserIdList;
    }
    
     @Override
    public String toString() {
        // You can customize the format of the output here
        return "PM Id: " + getPMID() + "\nUsername: " + super.GetUsername() + "\nPassword: " + super.GetPassword() + "\nRole: " + super.GetRole() + "\n\n";
    }
}
