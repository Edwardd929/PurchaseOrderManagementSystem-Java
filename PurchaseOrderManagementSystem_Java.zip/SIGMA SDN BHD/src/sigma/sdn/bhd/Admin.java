/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sigma.sdn.bhd;

import java.util.ArrayList;

/**
 *
 * @author vinni
 */
public class Admin extends User{
    public Admin(String AID){
        super(AID);
    }
    
    public String getAID() {
        return super.GetUserId();
    }

    public void setAID(String AID) {
        super.SetUserId(AID);
    }
    
    
    @Override
    protected ArrayList<String> GetAllUserId() {
        
        ArrayList<User> AllCustomerData = super.ReadUserData();
        
        ArrayList<String> AdminUserIdList = new ArrayList<>();

        for (int i=0;i<AllCustomerData.size();i++) {
            if(AllCustomerData.get(i).GetRole().equals("Admin")){
                String UserId = AllCustomerData.get(i).GetUserId();
                AdminUserIdList.add(UserId);
            }
        }
        return AdminUserIdList;
    }
    
    @Override
    public String toString() {
        // You can customize the format of the output here
        return "Admin Id: " + getAID() + "\nUsername: " + super.GetUsername() + "\nPassword: " + super.GetPassword() + "\nRole: " + super.GetRole() + "\n\n";
    }
}
