
package sigma.sdn.bhd;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;


public class SIGMASDNBHD {
    public static void main(String[] args){
        new JFrameLogin().setVisible(true);
 
    }
    
}
