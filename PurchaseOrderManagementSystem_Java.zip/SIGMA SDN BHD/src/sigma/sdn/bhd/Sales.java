/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sigma.sdn.bhd;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;


public class Sales extends DataCheck{
    private String SalesID;
    private int SalesQuantity;
    private String Status;
    private String date;
    private Item SalesItem;
   
    
    
    //read sales
    public Sales(String SalesID, Item SalesItem, int SalesQuantity,String date, String Status){
        super();
        this.SalesItem = SalesItem;
        this.SalesID = SalesID;
        this.SalesQuantity = SalesQuantity;
        this.date = date;
        this.Status = Status;
    }
    
    //insert sales
    public Sales(String SalesID,Item SalesItem, int SalesQuantity){
        super();
        this.SalesItem = SalesItem;
        this.SalesID = SalesID;
        this.SalesQuantity = SalesQuantity;
    }
    
    public Sales(Item SalesItem){
        super();
        this.SalesItem = SalesItem;
    }
    
    public Sales(String SalesID,Item SalesItem){
        super();
        this.SalesID = SalesID;
        this.SalesItem = SalesItem;
    }
    
    protected String GetSalesID(){
        return this.SalesID;
    }
    
    protected int GetSalesQuantity(){
        return this.SalesQuantity;
    }
    
    protected String GetStatus(){
        return this.Status;
    }
    
    protected String GetItemID(){
        return SalesItem.GetItemId();
    }
    
    protected String GetDate(){
        return this.date;
    }
    
    protected void SetDate(String date){
        this.date = date;
    }
    
    protected void SetDate(){
        this.date = SalesEntryDate();
    }
    
    
    protected void SetSalesID(String SalesID){
        this.SalesID = SalesID;
    }
    
    protected void SetSalesID(){
        this.SalesID = GenerateSalesID(ReadSalesData());
    }
    
    protected void SetStatus(String Status){
        this.Status = Status;
    }
    
    
    protected void SetItem(String ItemID){
        SalesItem.SetItemID(ItemID);
    }
    
    protected void SetSalesQuantity(int SalesQuantity){
        this.SalesQuantity = SalesQuantity;
    }
    
    private void SaveData(ArrayList<Sales> AllSalesData){
        File file = new File("data/DailySales.txt");
        // relative file paths

        try {
            // Create a FileWriter object to write to the file
            FileWriter writer = new FileWriter(file,false);
            
            for (int i = 0; i< AllSalesData.size(); i++) {
               // Write the user input to the file
                writer.write("Sales Id: "+ AllSalesData.get(i).GetSalesID() + "\n");
                writer.write("Item Id: " + AllSalesData.get(i).GetItemID() + "\n");
                writer.write("Sales Quantity: "+ AllSalesData.get(i).GetSalesQuantity()+ "\n" );
                writer.write("Date: "+ AllSalesData.get(i).GetDate()+ "\n" );
                writer.write("Status: "+ AllSalesData.get(i).GetStatus()+ "\n\n" );
            }    
            
            // Close the FileWriter
            writer.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    protected void AddSales(){
        File file = new File("data/DailySales.txt");
        // relative file paths

        try {
            // Create a FileWriter object to write to the file
            FileWriter writer = new FileWriter(file,true);
           
            
            // Write the user input to the file
            writer.write("Sales Id: "+ this.SalesID + "\n");
            writer.write("Item Id: " + this.GetItemID() + "\n");
            writer.write("Sales Quantity: " + this.SalesQuantity + "\n");
            writer.write("Date: " + this.GetDate() + "\n");
            writer.write("Status: A\n\n");
            

            // Close the FileWriter
            writer.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private ArrayList<Sales> ReadSalesData() {
        // Create a new file object to read from
        File SalesDataFile = new File("data/DailySales.txt");

        // Create an ArrayList to store the customer data
        ArrayList<Sales> AllSalesData = new ArrayList<>();


        try {
            // Create a new Scanner object to read from the file
            Scanner scanner = new Scanner(SalesDataFile);
            
            Sales ReadSales;
            // Read each line of the file
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();

                if (!line.trim().isEmpty()) {
                    String salesid = line.split(":")[1].trim();
                    String itemid = scanner.nextLine().split(":")[1].trim();
                    int salesquantity = Integer.parseInt(scanner.nextLine().split(":")[1].trim());
                    String Date = scanner.nextLine().split(":")[1].trim();
                    String Status = scanner.nextLine().split(":")[1].trim();
                    ReadSales = new Sales(salesid, new Item(itemid),salesquantity,Date,Status);
                    AllSalesData.add(ReadSales);
                }else{
                    ReadSales = null;
                    continue;
                }
                
            }
            // Close the scanner
            scanner.close();
            

        } catch (IOException e) {
            e.printStackTrace();
        }
        return AllSalesData;
    }
    
    //edit sales
    private boolean SaveData(ArrayList<Sales> AllSalesData,int SalesQuantity){
        int StockQuantity;
        String StockItemID = this.GetData("Item ID");
        int OriSalesQuantity = Integer.parseInt(this.GetData("Sales Quantity"));
        Stock EditStock = new Stock(StockItemID);
        StockQuantity = Integer.parseInt(EditStock.GetData("Stock Quantity"));
        StockQuantity+=OriSalesQuantity;

        
        int RemainQuantity =StockQuantity-SalesQuantity;
        if(RemainQuantity<0){
            return false;
        }else{
            File file = new File("data/DailySales.txt");
            // relative file paths

            try {
                // Create a FileWriter object to write to the file
                FileWriter writer = new FileWriter(file,false);


                for (int i = 0; i< AllSalesData.size(); i++) {

                    if(AllSalesData.get(i).GetSalesID().equals(this.GetSalesID())){
                       AllSalesData.get(i).SetSalesQuantity(SalesQuantity);
                    }

                    writer.write("Sales ID: "+ AllSalesData.get(i).GetSalesID() + "\n");
                    writer.write("Item ID: " + AllSalesData.get(i).GetItemID()+ "\n");
                    writer.write("Sales Quantity: " + SalesQuantity + "\n" );
                    writer.write("Date: " + AllSalesData.get(i).GetDate()+ "\n" );
                    writer.write("Status: " + AllSalesData.get(i).GetStatus()+ "\n\n" );
                }
                // Close the FileWriter
                writer.close();
                EditStock.EditStockQuantity(RemainQuantity);


            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return true;
    }
    
    private String GenerateSalesID(ArrayList<Sales> AllSalesInfo) {
        int maxID = 0;
        int currentID =0;
        for(Sales AS: AllSalesInfo){
            currentID = Integer.parseInt(AS.GetSalesID().substring(2));
            if(currentID>maxID){
                maxID= currentID;
            }  
        }
        if(maxID!=0){
            maxID++;
            String NewSalesId = "SA" + maxID;
            return NewSalesId;
        }else{
            maxID = 1;
            String NewSalesId = "SA" + maxID;
            return NewSalesId;
        }

    }
    
    
    
    private String[] GetAllSaleID(ArrayList<Sales> AllSalesData) {
        ArrayList<String> UniqueSaleIDs = new ArrayList<>();

        for (Sales sale : AllSalesData) {
            if (sale.GetStatus().equals("A")) {
                String saleID = sale.GetSalesID();
                if (!UniqueSaleIDs.contains(saleID)) {
                    UniqueSaleIDs.add(saleID);
                }
            }
        }

        // Convert the ArrayList to an array of Strings
        String[] SalesIDList = UniqueSaleIDs.toArray(new String[0]);

        return SalesIDList;
    }

    
    
    protected String[] GetAllSalesIDs(){
        return GetAllSaleID(ReadSalesData());
    }
    
    protected String GetSalesData(ArrayList<Sales> AllSalesData, String ItemID, String var){
        int size = AllSalesData.size();
        for(int i=0;i<size;i++){
            if(AllSalesData.get(i).GetSalesID().equals(this.GetSalesID())){
                if(var.equals("Sales ID")){
                    return (String.valueOf(AllSalesData.get(i).GetSalesID()));
                }else if(var.equals("Item ID")){
                    return (String.valueOf(AllSalesData.get(i).GetItemID()));
                }else if(var.equals("Sales Quantity")){
                    return (String.valueOf(AllSalesData.get(i).GetSalesQuantity()));
                }else if(var.equals("Date")){
                    return (String.valueOf(AllSalesData.get(i).GetDate()));
                }else if(var.equals("Status")){
                    return (String.valueOf(AllSalesData.get(i).GetStatus()));
                }
            }
        }
        return null;
    }
    
    protected String GetData(String var){
        return GetSalesData(ReadSalesData(),GetItemID(),var);
    }
    
    protected String CheckInput(){
        ArrayList<Sales> ALlSalesData = ReadSalesData();
        String SQ = Integer.toString(this.GetSalesQuantity());
        int SalesQuantityNum;
        if(this.GetSalesID().isEmpty() || this.GetItemID().isEmpty() ||SQ.isEmpty()){
            return "Incomplete";
        }else{
            try {
                SalesQuantityNum = Integer.parseInt(SQ);
            } catch (NumberFormatException e) {
                return "Not Number";
            }
            return "Correct";
        }
    }
    
    protected boolean NotExceedQuantity(){
        return SaveData(ReadSalesData(),this.GetSalesQuantity());
    }
   
    
    protected void DeleteSales(){
        
        ArrayList<Sales> DeleteSalesData = ReadSalesData();
        int StockQuantity;
        String StockItemID = this.GetData("Item ID");
       
        int OriSalesQuantity = Integer.parseInt(this.GetData("Sales Quantity"));
         
        Stock DeleteStock = new Stock(StockItemID);
        StockQuantity = Integer.parseInt(DeleteStock.GetData("Stock Quantity"));
        
        StockQuantity+=OriSalesQuantity;
        
        
        for (int i = 0; i< DeleteSalesData.size(); i++) {
            if (DeleteSalesData.get(i).GetSalesID().equals(this.GetSalesID())) {
                DeleteSalesData.get(i).SetStatus("NA");
                break;
            }
            DeleteStock.EditStockQuantity(StockQuantity);
        }
        SaveData(DeleteSalesData);
    }
    
    protected String SalesEntryDate(){
        Date date = new Date();
        LocalDateTime now = LocalDateTime.ofInstant(date.toInstant(), java.time.ZoneId.systemDefault());
        String FormattedDate = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        return FormattedDate;
    }
    
    
    protected ArrayList<String> GetItemFromSameDate() {
        ArrayList<Sales> AllSalesData = ReadSalesData();
        ArrayList<String> SameItemDateData = new ArrayList<>();

        for (Sales s : AllSalesData) {
            if (s.GetDate().equals(this.GetDate()) && s.GetStatus().equals("A")) {
                SameItemDateData.add(s.GetItemID());
            }
        }

        return SameItemDateData;
    }
    
    protected String GetSalesIDfromItemIDinSameDate() {
        ArrayList<Sales> AllSalesData = ReadSalesData();
       
        for (Sales s : AllSalesData) {
            if (s.GetDate().equals(this.GetDate()) && s.GetStatus().equals("A") 
                    && s.GetItemID().equals(this.GetItemID())) {
                String sid = s.GetSalesID();
                return sid;
            }
        }

        return null;
    }
    
    //check duplicated item in same date
    protected boolean DuplicatedCheck(){
        ArrayList<Sales> AllSalesData = ReadSalesData();
        for (Sales s : AllSalesData) {
            if (s.GetDate().equals(this.GetDate())&& s.GetStatus().equals("A")) {
                if(s.GetItemID().equals(this.GetItemID())){
                    return true;
                }
                
            }
        }
        return false;
    }
    
     public String toString(){
       return "Sales ID=" + this.SalesID + " Item ID=" + this.GetItemID() +  "Sales Quantity="+ this.GetSalesQuantity() +
               "Date"+this.GetDate();
   }
    
}
