/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package sigma.sdn.bhd;

import java.util.ArrayList;

/**
 *
 * @author vinni
 */
public interface PurchaseRequisitionManagement {
    String[] GetAllPRIDs();
    String[] GetFilterPRIDs();
    String[] GetISIDFromSamePRs();
    String[] GetFilterStatuss();
    
    ArrayList<String[]> GetPRDataArray();
    ArrayList<String[]> GetFilterPRIDPRArray(String PRID);
    ArrayList<String[]> GetFilterStatusPRArray(String Status);

}
