/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sigma.sdn.bhd;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

public class User implements java.io.Serializable{
    private static final long serialVersionUID = -1310107838731306520L;; // Set a unique value
     
    private String Username;
    private String Password;
    private String UserId;
    private String Role;
    private String role;
    private String login_date;
    private String login_time;
    
    public User(){
        //for view user
    }
    public User(String Username,String Password){
        this.Username = Username;
        this.Password = Password;
    }
    
    public User(String UserId, String Username,String Password, String Role){
        this.Username = Username;
        this.Password = Password;
        this.UserId = UserId;
        this.Role = Role;
    }
    
    public User(String UserId){
        this.UserId = UserId;
    }
    
    protected void SetRole(String Role){
        this.Role = Role;
    }
    
    protected void SetUserId(String UserId){
        this.UserId = UserId;
    }
    
    protected String GetUsername(){
        return this.Username;
    }
    
    protected String GetPassword(){
        return this.Password;
    }
    
    protected String GetUserId(){
        return this.UserId;
    }
    
    protected String GetRole(){
        return this.Role;
    }
    
    protected ArrayList<User> ReadUserData(){
        ArrayList<User> AllUserData = new ArrayList<>();
        try{
            // Create a new file object to read from
            File CustomerDataFile = new File("data/UserData.ser");

            FileInputStream file = new FileInputStream(CustomerDataFile);
            ObjectInputStream in = new ObjectInputStream(file);
            
            // Read the ArrayList from the file
            AllUserData = (ArrayList<User>) in.readObject();
            
            in.close();
            file.close();
        
        }catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        return AllUserData;
    }
    
    private boolean CheckUsernamePassword(String Username_Password,String CheckKey){
        ArrayList<User> AllCustomerData = ReadUserData();
        int size = AllCustomerData.size();
        
        if (Username_Password.equals("Password")){
            for(int i=0;i<size;i++){
                if(AllCustomerData.get(i).GetPassword().equals(CheckKey)){
                    return true;
                }
            }
        }else if(Username_Password.equals("Username")){
            for(int i=0;i<size;i++){
                if(AllCustomerData.get(i).GetUsername().equals(CheckKey)){
                    return true;
                }
            }
        }
        return false;
    }
   

    protected String GetUserData(String var){
        ArrayList<User> AllCustomerData = ReadUserData();
        int size = AllCustomerData.size();
        for(int i=0;i<size;i++){
            if(AllCustomerData.get(i).GetUsername().equals(this.Username)){
                if(var.equals("Password")){
                    return (AllCustomerData.get(i).GetPassword());
                }else if(var.equals("User Id")){
                    return (AllCustomerData.get(i).GetUserId());
                }else if(var.equals("Role")){
                    return (AllCustomerData.get(i).GetRole());
                }
            }
        }
        return null;
    }
        
    protected String CheckLoginInput(){
        if (Username.isEmpty() || Password.isEmpty()){
            return "Incomplete";
        }else if(!CheckUsernamePassword("Username",this.Username)){
            return "Incorrect Username";
        }else if(!CheckUsernamePassword("Password", this.Password)){
            return "Incorrect Password";
        }else{
            role = GetUserData("Role");
            login_date=UserLoginDate();
            login_time=UserLoginTime();
            return "Correct";
        }
    }
    
    protected String UserLoginDate(){
        Date date = new Date();
        LocalDateTime now = LocalDateTime.ofInstant(date.toInstant(), java.time.ZoneId.systemDefault());
        String FormattedDate = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        return FormattedDate;
    }

    protected String UserLoginTime(){
        Date date = new Date();
        LocalDateTime now = LocalDateTime.ofInstant(date.toInstant(), java.time.ZoneId.systemDefault());
        String FormattedTime = now.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
        return FormattedTime;
    }
    
    protected void RecordUserActivity(){
        File file = new File("data/UserLoginActivity.txt");
        // relative file paths

        try {
            // Create a FileWriter object to write to the file
            FileWriter writer = new FileWriter(file,true);

            // Write the user input to the file
            writer.write(Username + "\t" + this.role +"\t"+this.login_date + "\t" + this.login_time+ "\n");

            // Close the FileWriter
            writer.close();

            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    protected String CheckRegisterInput(String ConfirmPassword){
        if(Username.isEmpty() || Password.isEmpty()|| ConfirmPassword.isEmpty()){
            return "Incomplete";
        }else if(!Password.equals(ConfirmPassword)){
            return "Incorrect Password";
        }else{
            return "Correct";
        }
    }
    
    protected ArrayList<String> GetAllUserId() {
        
        ArrayList<User> AllCustomerData = ReadUserData();
        
        ArrayList<String> UserIdList = new ArrayList<>();

        for (int i=0;i<AllCustomerData.size();i++) {
            String UserId = AllCustomerData.get(i).GetUserId();
            UserIdList.add(UserId);
        }
        
        return UserIdList;
    }
        
    private String GenerateUserId() {
        int LatestUserId = 0;
        String RoleIndicator = null;
        if (Role.equals("Admin")){
            RoleIndicator = "A";
        }else if(Role.equals("Purchase Manager")){
            RoleIndicator = "P";
        }else if(Role.equals("Sales Manager")){
            RoleIndicator = "S";
        }
        
        ArrayList<String> AllUserId= GetAllUserId();
        
        for(int i = 0; i<AllUserId.size();i++){
             if(AllUserId.get(i).substring(0,1).equals(RoleIndicator)){
                 LatestUserId = Integer.parseInt(AllUserId.get(i).substring(1));
             }
        }
        LatestUserId++;
        String NewUserId = RoleIndicator + LatestUserId;
    
        return NewUserId;
    }

    private String[] GetUsernameList(ArrayList<User> AllUserData) {
        ArrayList<String> UsernameArrayList = new ArrayList<>();
        int size = AllUserData.size();

        for (int i = 0; i < size; i++) {
            UsernameArrayList.add(AllUserData.get(i).GetUsername());
        }

        // Convert the ArrayList to an array of Strings
        String[] UsernameList = new String[UsernameArrayList.size()];
        UsernameList = UsernameArrayList.toArray(UsernameList);

        return UsernameList;
    }

    protected boolean UsernameDuplicatedCheck(){
        for(int i = 0;i<GetUsernameList(ReadUserData()).length;i++){
            if (this.Username.equalsIgnoreCase(GetUsernameList(ReadUserData())[i])){
                return true;
            }
        }
        return false;
    }
    
    private ArrayList<User> AddNewUser(){
        User NewUser = new User(GenerateUserId(),this.Username,this.Password,this.Role);
        ArrayList<User> AllUserData = ReadUserData();
        AllUserData.add(NewUser);
        return AllUserData;
    }
    
    protected void SaveNewUserData(){
        ArrayList<User> AllUserData = AddNewUser();
        
        // Create a new file to save the user input
        File FileName = new File("data/UserData.ser");
        
        // Create the data directory if it doesn't exist
        if (!FileName.getParentFile().exists()) {
            FileName.getParentFile().mkdirs();
        }
        
        try {
            FileOutputStream file = new FileOutputStream(FileName);
            ObjectOutputStream out = new ObjectOutputStream(file);
            out.writeObject(AllUserData);
            out.close();
            file.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private ArrayList<String[]> CreateUserArray(ArrayList<User> AllUserData){
        ArrayList<String[]> UserList = new ArrayList<>();

        for (int i = 0; i< AllUserData.size();i++) {
            String UserId = AllUserData.get(i).GetUserId();
            String[] User = new String[]{
                UserId,
                AllUserData.get(i).GetUsername(),
                AllUserData.get(i).GetPassword(),
                AllUserData.get(i).GetRole()
            };
                
            UserList.add(User);
        }

        return UserList;
    }
    
    protected ArrayList<String[]> GetUserDataArray(){
        return CreateUserArray(ReadUserData());
    }
    
    public String toString(){
        return "User Id: " + UserId + "\nUsername: " + Username + "\nPassword: "+ Role+ "\nRole: "+ Role + "\n\n";
    }
}
